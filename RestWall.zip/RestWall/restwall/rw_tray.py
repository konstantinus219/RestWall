import os

import gi

from gi.repository import Gio, GLib  # noqa: E402

SNI_PATH = "/StatusNotifierItem"
MENU_PATH = "/MenuBar"
SNI_IFACE = "org.kde.StatusNotifierItem"
MENU_IFACE = "com.canonical.dbusmenu"

SNI_XML = """<node><interface name="org.kde.StatusNotifierItem">
<method name="Activate"><arg type="i" direction="in"/><arg type="i" direction="in"/></method>
<method name="SecondaryActivate"><arg type="i" direction="in"/><arg type="i" direction="in"/></method>
<method name="ContextMenu"><arg type="i" direction="in"/><arg type="i" direction="in"/></method>
<method name="Scroll"><arg type="i" direction="in"/><arg type="s" direction="in"/></method>
<property name="Category" type="s" access="read"/>
<property name="Id" type="s" access="read"/>
<property name="Title" type="s" access="read"/>
<property name="Status" type="s" access="read"/>
<property name="WindowId" type="i" access="read"/>
<property name="IconName" type="s" access="read"/>
<property name="IconPixmap" type="a(iiay)" access="read"/>
<property name="OverlayIconName" type="s" access="read"/>
<property name="AttentionIconName" type="s" access="read"/>
<property name="ToolTip" type="(sa(iiay)ss)" access="read"/>
<property name="ItemIsMenu" type="b" access="read"/>
<property name="Menu" type="o" access="read"/>
<signal name="NewTitle"/><signal name="NewIcon"/><signal name="NewToolTip"/>
<signal name="NewStatus"><arg type="s"/></signal>
</interface></node>"""

MENU_XML = """<node><interface name="com.canonical.dbusmenu">
<method name="GetLayout"><arg type="i" direction="in"/><arg type="i" direction="in"/><arg type="as" direction="in"/>
<arg type="u" direction="out"/><arg type="(ia{sv}av)" direction="out"/></method>
<method name="GetGroupProperties"><arg type="ai" direction="in"/><arg type="as" direction="in"/>
<arg type="a(ia{sv})" direction="out"/></method>
<method name="GetProperty"><arg type="i" direction="in"/><arg type="s" direction="in"/><arg type="v" direction="out"/></method>
<method name="Event"><arg type="i" direction="in"/><arg type="s" direction="in"/><arg type="v" direction="in"/>
<arg type="u" direction="in"/></method>
<method name="EventGroup"><arg type="a(isvu)" direction="in"/><arg type="ai" direction="out"/></method>
<method name="AboutToShow"><arg type="i" direction="in"/><arg type="b" direction="out"/></method>
<method name="AboutToShowGroup"><arg type="ai" direction="in"/><arg type="ai" direction="out"/><arg type="ai" direction="out"/></method>
<signal name="ItemsPropertiesUpdated"><arg type="a(ia{sv})"/><arg type="a(ias)"/></signal>
<signal name="LayoutUpdated"><arg type="u"/><arg type="i"/></signal>
<signal name="ItemActivationRequested"><arg type="i"/><arg type="u"/></signal>
<property name="Version" type="u" access="read"/>
<property name="TextDirection" type="s" access="read"/>
<property name="Status" type="s" access="read"/>
<property name="IconThemePath" type="as" access="read"/>
</interface></node>"""


class Tray:
    """StatusNotifierItem tray icon with a context menu. Works on KDE, Sway/Hyprland (waybar etc.)
    and GNOME with the AppIndicator extension."""

    def __init__(self, actions, get_state, icon="preferences-system-time"):
        self.actions = actions
        self.get_state = get_state
        self.icon = icon
        self.conn = None
        self.name = None
        self.regs = []
        self.owner_id = 0
        self.watch_id = 0
        self.running = False
        self.available = False
        self.revision = 1
        self.menu_sig = None
        self.tooltip = "RestWall"
        self.status = "Active"

    # ---- lifecycle
    def set_enabled(self, on):
        self.start() if on else self.stop()

    def start(self):
        if self.running:
            return
        try:
            self.conn = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            sni = Gio.DBusNodeInfo.new_for_xml(SNI_XML).interfaces[0]
            menu = Gio.DBusNodeInfo.new_for_xml(MENU_XML).interfaces[0]
            self.regs = [
                self.conn.register_object(SNI_PATH, sni, self._sni_call, self._sni_get, None),
                self.conn.register_object(MENU_PATH, menu, self._menu_call, self._menu_get, None),
            ]
        except GLib.Error:
            self.regs = []
            return
        self.running = True
        self.name = "org.kde.StatusNotifierItem-%d-1" % os.getpid()
        self.owner_id = Gio.bus_own_name_on_connection(self.conn, self.name, Gio.BusNameOwnerFlags.NONE, None, None)
        self.watch_id = Gio.bus_watch_name_on_connection(
            self.conn, "org.kde.StatusNotifierWatcher", Gio.BusNameWatcherFlags.NONE,
            self._appeared, self._vanished)
        self.refresh(force=True)

    def stop(self):
        if not self.running:
            return
        self.running = False
        self.available = False
        for r in self.regs:
            try:
                self.conn.unregister_object(r)
            except GLib.Error:
                pass
        self.regs = []
        Gio.bus_unown_name(self.owner_id)
        Gio.bus_unwatch_name(self.watch_id)

    def status_text(self):
        if not self.running:
            return "Tray icon is off."
        if self.available:
            return "Tray icon is shown."
        return "No system tray found. GNOME needs the AppIndicator extension; KDE, Sway and Hyprland work."

    def _appeared(self, conn, name, owner):
        self.available = True
        conn.call(name, "/StatusNotifierWatcher", "org.kde.StatusNotifierWatcher", "RegisterStatusNotifierItem",
                  GLib.Variant("(s)", (self.name,)), None, Gio.DBusCallFlags.NONE, 2000, None, None, None)

    def _vanished(self, conn, name):
        self.available = False

    # ---- state
    def refresh(self, force=False):
        if not self.running:
            return
        st = self.get_state()
        tip = st["line"]
        status = "NeedsAttention" if st["locked"] else "Active"
        if tip != self.tooltip or force:
            self.tooltip = tip
            self._emit(SNI_PATH, SNI_IFACE, "NewToolTip", None)
        if status != self.status or force:
            self.status = status
            self._emit(SNI_PATH, SNI_IFACE, "NewStatus", GLib.Variant("(s)", (status,)))
        sig = (st["line"], st["locked"], st["enabled"], st["postpones"])
        if sig != self.menu_sig:
            self.menu_sig = sig
            self.revision += 1
            self._emit(MENU_PATH, MENU_IFACE, "LayoutUpdated", GLib.Variant("(ui)", (self.revision, 0)))

    def _emit(self, path, iface, signal, params):
        try:
            self.conn.emit_signal(None, path, iface, signal, params)
        except GLib.Error:
            pass

    def _do(self, action):
        cb = self.actions.get(action)
        if cb:
            GLib.idle_add(lambda: cb() or False)

    # ---- StatusNotifierItem
    def _sni_call(self, conn, sender, path, iface, method, params, inv):
        if method == "Activate":
            self._do("toggle")
        inv.return_value(None)

    def _sni_get(self, conn, sender, path, iface, prop):
        table = {
            "Category": ("s", "ApplicationStatus"), "Id": ("s", "restwall"), "Title": ("s", "RestWall"),
            "Status": ("s", self.status), "WindowId": ("i", 0), "IconName": ("s", self.icon),
            "IconPixmap": ("a(iiay)", []), "OverlayIconName": ("s", ""),
            "AttentionIconName": ("s", "dialog-warning"),
            "ToolTip": ("(sa(iiay)ss)", (self.icon, [], "RestWall", self.tooltip)),
            "ItemIsMenu": ("b", False), "Menu": ("o", MENU_PATH),
        }
        if prop in table:
            sig, val = table[prop]
            return GLib.Variant(sig, val)
        return None

    # ---- dbusmenu
    def _items(self):
        st = self.get_state()
        busy = st["locked"]
        return [
            (1, st["line"], False, None),
            (2, None, False, None),
            (3, "Open RestWall", True, "open"),
            (4, "Take a break now", not busy, "rest"),
            (5, "Postpone +%d min (%d left)" % (st["postpone_minutes"], st["postpones"]),
             st["postpones"] > 0 and not busy, "postpone"),
            (6, "Pause monitoring" if st["enabled"] else "Resume monitoring", not busy, "pause"),
            (7, None, False, None),
            (8, "Quit RestWall", not busy, "quit"),
        ]

    @staticmethod
    def _props(label, enabled):
        if label is None:
            return {"type": GLib.Variant("s", "separator")}
        return {"label": GLib.Variant("s", label), "enabled": GLib.Variant("b", enabled)}

    def _layout(self):
        kids = [GLib.Variant("(ia{sv}av)", (i, self._props(label, en), []))
                for i, label, en, _a in self._items()]
        return (0, {"children-display": GLib.Variant("s", "submenu")}, kids)

    def _click(self, item_id, event):
        if event == "clicked":
            for i, _label, _en, action in self._items():
                if i == item_id and action:
                    self._do(action)

    def _menu_call(self, conn, sender, path, iface, method, params, inv):
        args = params.unpack()
        if method == "GetLayout":
            inv.return_value(GLib.Variant("(u(ia{sv}av))", (self.revision, self._layout())))
        elif method == "GetGroupProperties":
            ids = args[0]
            props = [(i, self._props(label, en)) for i, label, en, _a in self._items() if not ids or i in ids]
            inv.return_value(GLib.Variant("(a(ia{sv}))", (props,)))
        elif method == "GetProperty":
            inv.return_value(GLib.Variant("(v)", (GLib.Variant("s", ""),)))
        elif method == "Event":
            self._click(args[0], args[1])
            inv.return_value(None)
        elif method == "EventGroup":
            for item_id, event, _data, _ts in args[0]:
                self._click(item_id, event)
            inv.return_value(GLib.Variant("(ai)", ([],)))
        elif method == "AboutToShow":
            inv.return_value(GLib.Variant("(b)", (True,)))
        elif method == "AboutToShowGroup":
            inv.return_value(GLib.Variant("(aiai)", ([], [])))
        else:
            inv.return_value(None)

    def _menu_get(self, conn, sender, path, iface, prop):
        table = {"Version": ("u", 3), "TextDirection": ("s", "ltr"), "Status": ("s", "normal"),
                 "IconThemePath": ("as", [])}
        if prop in table:
            sig, val = table[prop]
            return GLib.Variant(sig, val)
        return None
