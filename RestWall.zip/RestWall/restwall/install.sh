#!/bin/sh
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
APPDIR="$HOME/.local/share/restwall"
BIN="$HOME/.local/bin"
mkdir -p "$APPDIR/app" "$BIN" "$HOME/.local/share/applications"
install -m 755 "$SRC/restwall.py" "$APPDIR/app/restwall.py"
install -m 644 "$SRC/rw_common.py" "$SRC/rw_stats.py" "$SRC/rw_ui.py" "$SRC/rw_tray.py" "$SRC/rw_theme.py" "$APPDIR/app/"
cat > "$BIN/restwall" <<EOT
#!/bin/sh
exec python3 "$APPDIR/app/restwall.py" "\$@"
EOT
chmod 755 "$BIN/restwall"
cat > "$HOME/.local/share/applications/restwall.desktop" <<EOT
[Desktop Entry]
Type=Application
Name=RestWall
Comment=Screen time limit, forced rest and usage statistics
Exec=$BIN/restwall
Icon=preferences-system-time
Categories=Utility;GTK;
Terminal=false
EOT
echo "Installed. Run: restwall"
