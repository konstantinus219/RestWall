import datetime
import json
import math
import os
import re
import shutil
import subprocess
import time

GUI_LIBS = (b"libwayland-client", b"libxcb.so", b"libX11.so")

SYSTEM_DENY = (
    "gnome-shell", "gnome-session", "gnome-keyring", "gnome-settings", "gsd-", "mutter", "kwin", "plasma", "kded",
    "kglobal", "ksmserver", "kscreen", "kactivity", "sway", "hyprland", "waybar", "labwc", "wayfire", "river", "niri",
    "cosmic-", "xdg-", "xwayland", "pipewire", "wireplumber", "pulseaudio", "dbus", "systemd", "polkit", "ibus",
    "fcitx", "at-spi", "gvfs", "evolution-", "tracker", "localsearch", "ssh-agent", "gpg-agent", "goa-", "dconf",
    "upowerd", "bluetooth", "blueman", "nm-applet", "networkmanager", "pasystray", "swaync", "mako", "dunst",
    "swaybg", "swayidle", "swaylock", "hypr", "wl-", "rofi", "wofi", "fuzzel", "tofi", "polybar", "xfce4-panel",
    "xfdesktop", "xfwm4", "lxqt-panel", "cinnamon", "muffin", "budgie", "mate-panel", "snapd", "restwall",
    "sshd", "gjs-console", "tmux",
)


def boot():
    return time.clock_gettime(time.CLOCK_BOOTTIME)


def today():
    return datetime.date.today().isoformat()


def fmt(sec):
    sec = int(max(0, sec))
    return "%d:%02d:%02d" % (sec // 3600, sec % 3600 // 60, sec % 60)


def fmt_ms(sec):
    sec = int(math.ceil(max(0, sec)))
    return "%02d:%02d" % (sec // 60, sec % 60)


def parse_hm(text, default):
    try:
        return datetime.datetime.strptime(str(text).strip(), "%H:%M").time()
    except ValueError:
        return default


def load_json(path, default):
    try:
        with open(path) as f:
            data = json.load(f)
        if isinstance(data, dict):
            return {**default, **data}
    except (OSError, ValueError):
        pass
    return dict(default)


def save_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, path)
    except OSError:
        pass


def read_bytes(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except OSError:
        return b""


def proc_info(pid):
    raw = read_bytes("/proc/%d/stat" % pid).decode(errors="ignore")
    if not raw:
        return None
    lp, rp = raw.find("("), raw.rfind(")")
    rest = raw[rp + 2:].split()
    if len(rest) < 20:
        return None
    return {"comm": raw[lp + 1:rp], "ppid": int(rest[1]), "start": rest[19]}


def self_pids():
    pids, p = set(), os.getpid()
    while p > 1 and p not in pids:
        pids.add(p)
        info = proc_info(p)
        if not info:
            break
        p = info["ppid"]
    return pids


def window_titles():
    out = {}
    if os.environ.get("SWAYSOCK") and shutil.which("swaymsg"):
        try:
            tree = json.loads(subprocess.check_output(["swaymsg", "-t", "get_tree"], timeout=2))

            def walk(n):
                if "pid" in n and n.get("name"):
                    out.setdefault(n["pid"], []).append(n["name"])
                for c in n.get("nodes", []) + n.get("floating_nodes", []):
                    walk(c)

            walk(tree)
        except Exception:
            pass
    if os.environ.get("HYPRLAND_INSTANCE_SIGNATURE") and shutil.which("hyprctl"):
        try:
            for c in json.loads(subprocess.check_output(["hyprctl", "clients", "-j"], timeout=2)):
                out.setdefault(c.get("pid"), []).append(c.get("title", ""))
        except Exception:
            pass
    return out


class ProcScan:
    def __init__(self):
        self.cache = {}

    @staticmethod
    def procs():
        uid, procs = os.getuid(), {}
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid != uid:
                    continue
            except OSError:
                continue
            pid = int(d)
            info = proc_info(pid)
            if not info:
                continue
            try:
                info["exe"] = os.path.basename(os.readlink("/proc/%d/exe" % pid))
            except OSError:
                info["exe"] = info["comm"]
            procs[pid] = info
        return procs

    def is_gui(self, pid, start, now):
        k = (pid, start)
        hit = self.cache.get(k)
        if hit and (hit[0] or now - hit[1] < 6):
            return hit[0]
        data = read_bytes("/proc/%d/maps" % pid)
        v = any(lib in data for lib in GUI_LIBS)
        self.cache[k] = (v, now)
        return v

    @staticmethod
    def names(pid, p):
        out = []
        cg = read_bytes("/proc/%d/cgroup" % pid).decode(errors="ignore")
        m = re.search(r"app-flatpak-(.+?)-\d+\.scope", cg)
        if m:
            out.append(m.group(1))
        out += [p["exe"], p["comm"]]
        for a in read_bytes("/proc/%d/cmdline" % pid).split(b"\0")[:2]:
            a = a.decode(errors="ignore")
            if a:
                out.append(os.path.basename(a))
        seen, res = set(), []
        for n in out:
            if n and n.lower() not in seen:
                seen.add(n.lower())
                res.append(n)
        return res

    def top_level_gui(self, safe=()):
        now = time.time()
        procs = self.procs()
        self.cache = {k: v for k, v in self.cache.items() if k[0] in procs}
        gui = {pid: p for pid, p in procs.items() if pid not in safe and self.is_gui(pid, p["start"], now)}
        apps = []
        for pid, p in gui.items():
            par = gui.get(p["ppid"])
            if par and par["exe"] == p["exe"]:
                continue
            q = dict(p)
            q["pid"] = pid
            q["names"] = self.names(pid, p)
            apps.append(q)
        return apps, procs
