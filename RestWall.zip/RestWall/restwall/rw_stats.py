import csv
import datetime
import json
import os
import shutil
import subprocess
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from rw_common import SYSTEM_DENY, ProcScan, fmt, load_json, save_json  # noqa: E402
from rw_theme import HAS_CAIRO, BarChart, bar_row  # noqa: E402

RANGES = [("Today", 1), ("Last 7 days", 7), ("Last 30 days", 30)]


class Stats:
    KEYS = {
        "screen": 0.0, "rest": 0.0, "away": 0.0, "breaks": 0, "cut_short": 0, "emergency": 0,
        "caught": 0, "sessions": 0, "postponed": 0, "longest": 0.0,
    }

    def __init__(self, path):
        self.path = path
        self.days = load_json(path, {"days": {}}).get("days", {})
        self._saved = 0.0
        keep = sorted(self.days)[-120:]
        self.days = {d: self.days[d] for d in keep}

    def day(self, d=None):
        d = d or datetime.date.today().isoformat()
        rec = self.days.get(d)
        if rec is None:
            rec = self.days[d] = {"apps": {}}
        rec.setdefault("apps", {})
        for k, v in self.KEYS.items():
            rec.setdefault(k, v)
        return rec

    def add(self, key, v):
        self.day()[key] += v
        self._maybe_save()

    def add_app(self, name, v):
        apps = self.day()["apps"]
        apps[name] = apps.get(name, 0.0) + v

    def maxset(self, key, v):
        rec = self.day()
        rec[key] = max(rec[key], v)

    def _maybe_save(self):
        if time.time() - self._saved > 15:
            self.save()

    def save(self):
        self._saved = time.time()
        save_json(self.path, {"days": self.days})

    def dates(self, n):
        t = datetime.date.today()
        return [(t - datetime.timedelta(days=i)).isoformat() for i in range(n - 1, -1, -1)]

    def aggregate(self, n):
        agg = {k: 0 for k in self.KEYS}
        agg["apps"], agg["days"] = {}, 0
        for d in self.dates(n):
            rec = self.days.get(d)
            if not rec:
                continue
            agg["days"] += 1
            for k in self.KEYS:
                if k == "longest":
                    agg[k] = max(agg[k], rec.get(k, 0))
                else:
                    agg[k] += rec.get(k, 0)
            for a, s in rec.get("apps", {}).items():
                agg["apps"][a] = agg["apps"].get(a, 0.0) + s
        return agg

    def streak(self, goal):
        n, t = 0, datetime.date.today()
        for i in range(120):
            rec = self.days.get((t - datetime.timedelta(days=i)).isoformat())
            if rec is None:
                continue
            if rec.get("screen", 0) > goal:
                break
            n += 1
        return n

    def export_csv(self, folder):
        os.makedirs(folder, exist_ok=True)
        cols = ["screen", "rest", "away", "breaks", "cut_short", "emergency", "caught", "sessions", "longest", "postponed"]
        with open(os.path.join(folder, "daily.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["date"] + [c + ("_seconds" if c in ("screen", "rest", "away", "longest") else "") for c in cols])
            for d in sorted(self.days):
                w.writerow([d] + [round(self.days[d].get(c, 0), 1) for c in cols])
        with open(os.path.join(folder, "apps.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["date", "app", "seconds"])
            for d in sorted(self.days):
                for a, s in sorted(self.days[d].get("apps", {}).items(), key=lambda x: -x[1]):
                    w.writerow([d, a, round(s, 1)])
        return folder


class ActiveApp:
    BACKENDS = ("sway", "hypr", "gnome_focused", "gnome_windows", "kde")

    def __init__(self, safe):
        self.safe = set(safe)
        self.current = []
        self.mode = "detecting"
        self.scan = ProcScan()
        self.cache = {}
        self.backend = None
        self.fail = 0
        self.next_probe = 0.0
        self.bus = None

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        try:
            self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except GLib.Error:
            self.bus = None
        while True:
            try:
                self.current = self._sample()
            except Exception:
                self.current = []
            time.sleep(2)

    def _sample(self):
        now = time.time()
        r = None
        if self.backend is None and now >= self.next_probe:
            for b in self.BACKENDS:
                try:
                    v = getattr(self, "_b_" + b)()
                except Exception:
                    v = None
                if v is not None:
                    self.backend, self.mode, self.fail, r = b, b, 0, v
                    break
            else:
                self.mode = "open"
                self.next_probe = now + 60
        elif self.backend:
            try:
                r = getattr(self, "_b_" + self.backend)()
                self.fail = 0
            except Exception:
                self.fail += 1
                if self.fail >= 15:
                    self.backend, self.next_probe = None, 0.0
                return []
        if self.backend:
            if not r or "restwall" in r.lower():
                return []
            return [self.pretty(r)]
        return self._open()

    def _b_sway(self):
        if not (os.environ.get("SWAYSOCK") and shutil.which("swaymsg")):
            return None
        tree = json.loads(subprocess.check_output(["swaymsg", "-t", "get_tree"], timeout=2))
        found = []

        def walk(n):
            if n.get("focused") and "pid" in n:
                found.append(n.get("app_id") or (n.get("window_properties") or {}).get("class") or "")
            for c in n.get("nodes", []) + n.get("floating_nodes", []):
                walk(c)

        walk(tree)
        return found[0] if found else ""

    def _b_hypr(self):
        if not (os.environ.get("HYPRLAND_INSTANCE_SIGNATURE") and shutil.which("hyprctl")):
            return None
        d = json.loads(subprocess.check_output(["hyprctl", "activewindow", "-j"], timeout=2) or b"{}")
        return d.get("class") or d.get("initialClass") or ""

    def _dbus_json(self, path, iface, method):
        if self.bus is None or "GNOME" not in os.environ.get("XDG_CURRENT_DESKTOP", "").upper():
            return None
        try:
            r = self.bus.call_sync("org.gnome.Shell", path, iface, method, None, None,
                                   Gio.DBusCallFlags.NONE, 800, None)
        except GLib.Error:
            return None
        return json.loads(r.unpack()[0])

    def _b_gnome_focused(self):
        d = self._dbus_json("/org/gnome/shell/extensions/FocusedWindow",
                            "org.gnome.shell.extensions.FocusedWindow", "Get")
        if d is None:
            return "" if self.backend == "gnome_focused" else None
        return d.get("wm_class") or d.get("wm_class_instance") or ""

    def _b_gnome_windows(self):
        d = self._dbus_json("/org/gnome/Shell/Extensions/Windows", "org.gnome.Shell.Extensions.Windows", "List")
        if d is None:
            return "" if self.backend == "gnome_windows" else None
        for w in d:
            if w.get("focus"):
                return w.get("wm_class") or ""
        return ""

    def _b_kde(self):
        if "KDE" not in os.environ.get("XDG_CURRENT_DESKTOP", "").upper() or not shutil.which("kdotool"):
            return None
        try:
            out = subprocess.check_output(["kdotool", "getactivewindow", "getwindowclassname"],
                                          timeout=2, stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError:
            return ""
        return out.decode(errors="ignore").strip()

    def _open(self):
        apps, _procs = self.scan.top_level_gui(self.safe)
        names = set()
        for a in apps:
            if any(s in n.lower() for s in SYSTEM_DENY for n in a["names"]):
                continue
            names.add(self.pretty(*a["names"]))
        return sorted(names)

    def pretty(self, *cands):
        key = cands[0]
        if key in self.cache:
            return self.cache[key]
        name = None
        for c in cands:
            for cid in (c, c.lower()):
                info = Gio.DesktopAppInfo.new(cid + ".desktop")
                if info:
                    name = info.get_name()
                    break
            if name:
                break
        if not name:
            try:
                for group in Gio.DesktopAppInfo.search(key):
                    for did in group:
                        info = Gio.DesktopAppInfo.new(did)
                        if info and info.should_show():
                            name = info.get_name()
                            break
                    if name:
                        break
            except Exception:
                pass
        if not name:
            name = key.split(".")[-1].replace("-", " ").replace("_", " ").title()
        self.cache[key] = name
        return name


def _clear(w):
    c = w.get_first_child()
    while c is not None:
        nxt = c.get_next_sibling()
        w.remove(c)
        c = nxt


def _card(title):
    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    card.add_css_class("rw-card")
    h = Gtk.Label(label=title, xalign=0)
    h.add_css_class("rw-h2")
    card.append(h)
    return card


class StatsPage(Gtk.Box):
    def __init__(self, engine):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16,
                         margin_top=26, margin_bottom=26, margin_start=30, margin_end=30)
        self.e = engine
        self.range = 0

        head = Gtk.Box(spacing=12)
        title = Gtk.Label(label="Statistics", xalign=0, hexpand=True)
        title.add_css_class("rw-h1")
        seg = Gtk.Box(valign=Gtk.Align.CENTER)
        seg.add_css_class("rw-seg")
        first = None
        for i, (label, _n) in enumerate(RANGES):
            b = Gtk.ToggleButton(label=label)
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.set_active(i == 0)
            b.connect("toggled", self._on_range, i)
            seg.append(b)
        head.append(title)
        head.append(seg)
        self.append(head)

        self.mode = Gtk.Label(xalign=0, wrap=True)
        self.mode.add_css_class("rw-hint")
        self.append(self.mode)

        self.tiles = Gtk.Grid(row_spacing=12, column_spacing=12, column_homogeneous=True)
        self.append(self.tiles)

        self.apps_card = _card("TIME PER APP")
        self.apps = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.apps_card.append(self.apps)
        self.append(self.apps_card)

        self.week_card = _card("LAST 7 DAYS")
        self.chart = BarChart() if HAS_CAIRO else None
        self.days = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.week_card.append(self.chart if self.chart else self.days)
        legend = Gtk.Label(use_markup=True, xalign=0, label=(
            '<span foreground="#7c5cff">\u25cf</span> Screen time    '
            '<span foreground="#34e69e">\u25cf</span> Rest and time away'))
        legend.add_css_class("rw-hint")
        self.week_card.append(legend)
        self.append(self.week_card)

        row = Gtk.Box(spacing=10)
        export = Gtk.Button(label="Export CSV")
        export.add_css_class("rw-btn")
        export.connect("clicked", self.on_export)
        self.out = Gtk.Label(xalign=0, wrap=True, valign=Gtk.Align.CENTER)
        self.out.add_css_class("rw-hint")
        row.append(export)
        row.append(self.out)
        self.append(row)
        self.refresh()

    def _on_range(self, btn, i):
        if btn.get_active():
            self.range = i
            self.refresh()

    def on_export(self, _b):
        folder = self.e.stats.export_csv(os.path.expanduser("~/RestWall-export"))
        self.out.set_label("Exported to " + folder)

    @staticmethod
    def _tile(title, value):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        card.add_css_class("rw-card")
        t = Gtk.Label(label=title.upper(), xalign=0)
        t.add_css_class("rw-cap")
        v = Gtk.Label(label=value, xalign=0)
        v.add_css_class("rw-tile-value")
        card.append(t)
        card.append(v)
        return card

    def refresh(self):
        st = self.e.stats
        a = st.aggregate(RANGES[self.range][1])
        mode = self.e.apps.mode
        if mode in ("open", "detecting"):
            self.mode.set_label("App tracking measures how long apps are open (no focus detection on this desktop). "
                                "GNOME: install the Window Calls or Focused Window D-Bus extension. KDE: install kdotool.")
        else:
            self.mode.set_label("App tracking uses the focused window (%s)." % mode)

        _clear(self.tiles)
        goal = self.e.cfg["daily_goal_hours"] * 3600
        top_app = max(a["apps"].items(), key=lambda x: x[1])[0] if a["apps"] else "-"
        tiles = [
            ("Screen time", fmt(a["screen"])), ("Daily average", fmt(a["screen"] / max(1, a["days"]))),
            ("Top app", top_app), ("Forced rest", fmt(a["rest"])), ("Time away (5+ min)", fmt(a["away"])),
            ("Breaks completed", str(a["breaks"])), ("Longest session", fmt(a["longest"])),
            ("Caught by camera", str(a["caught"])), ("Back at the screen", str(a["sessions"])),
            ("Postponed", str(a["postponed"])), ("Cut short / emergency", "%d / %d" % (a["cut_short"], a["emergency"])),
            ("Goal streak", "%d day(s)" % st.streak(goal) if goal > 0 else "off"),
        ]
        for i, (k, v) in enumerate(tiles):
            self.tiles.attach(self._tile(k, v), i % 3, i // 3, 1, 1)

        _clear(self.apps)
        top = sorted(a["apps"].items(), key=lambda x: -x[1])[:8]
        if not top:
            lbl = Gtk.Label(label="No app data yet. It fills in while you use your computer.", xalign=0)
            lbl.add_css_class("rw-hint")
            self.apps.append(lbl)
        for i, (name, secs) in enumerate(top, 1):
            self.apps.append(bar_row(name, fmt(secs), secs / top[0][1], rank=i))

        week = [(d, st.days.get(d, {})) for d in st.dates(7)]
        if self.chart is not None:
            self.chart.set_data([(datetime.date.fromisoformat(d).strftime("%a"), r.get("screen", 0),
                                  r.get("rest", 0) + r.get("away", 0)) for d, r in week])
        else:
            _clear(self.days)
            peak = max([r.get("screen", 0) for _d, r in week] + [1])
            for d, r in week:
                self.days.append(bar_row(datetime.date.fromisoformat(d).strftime("%a %d"),
                                         "%s | rest %s" % (fmt(r.get("screen", 0)), fmt(r.get("rest", 0) + r.get("away", 0))),
                                         r.get("screen", 0) / peak))
