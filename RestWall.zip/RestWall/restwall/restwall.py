#!/usr/bin/env python3
import os
import sys


def _preload_layer_shell():
    if os.environ.get("RESTWALL_PRELOAD") or not os.environ.get("WAYLAND_DISPLAY"):
        return
    import ctypes.util
    import glob

    lib = ctypes.util.find_library("gtk4-layer-shell")
    if not lib:
        for pat in (
            "/usr/lib*/libgtk4-layer-shell.so*",
            "/usr/lib/*/libgtk4-layer-shell.so*",
            "/usr/local/lib*/libgtk4-layer-shell.so*",
        ):
            found = sorted(glob.glob(pat))
            if found:
                lib = found[0]
                break
    if not lib:
        return
    env = dict(os.environ)
    env["RESTWALL_PRELOAD"] = "1"
    env["LD_PRELOAD"] = (lib + " " + env.get("LD_PRELOAD", "")).strip()
    try:
        os.execve(sys.executable, [sys.executable] + sys.argv, env)
    except OSError:
        pass


if __name__ == "__main__":
    _preload_layer_shell()

import datetime
import math
import re
import shutil
import signal
import subprocess
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

try:
    import cv2
except ImportError:
    cv2 = None

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rw_common import (SYSTEM_DENY, ProcScan, boot, fmt, fmt_ms, load_json, parse_hm,  # noqa: E402
                       proc_info, save_json, self_pids, today, window_titles)
from rw_stats import ActiveApp, Stats  # noqa: E402
from rw_tray import Tray  # noqa: E402
from rw_theme import apply_theme  # noqa: E402
from rw_ui import LockWindow, MainWindow  # noqa: E402

if os.environ.get("WAYLAND_DISPLAY"):
    os.environ.setdefault("GDK_BACKEND", "wayland,x11")

APP_ID = "io.github.restwall"
BACKGROUND = "--background" in sys.argv
CFG_FILE = os.path.join(GLib.get_user_config_dir(), "restwall", "config.json")
STATE_FILE = os.path.join(GLib.get_user_data_dir(), "restwall", "state.json")
STATS_FILE = os.path.join(GLib.get_user_data_dir(), "restwall", "stats.json")
AUTOSTART_FILE = os.path.join(GLib.get_user_config_dir(), "autostart", "restwall.desktop")
GRACE = 8
AWAY_MIN = 300

DEFAULT_PROTECTED = [
    "kdenlive", "melt", "openshot", "shotcut", "olive", "flowblade", "pitivi", "davinci", "resolve",
    "blender", "handbrake", "obs", "ffmpeg", "audacity", "ardour", "lmms", "reaper",
    "libreoffice", "soffice", "oosplash", "onlyoffice", "desktopeditors", "wps", "abiword", "gnumeric", "calligra",
    "krita", "gimp", "inkscape", "scribus",
    "code", "codium", "jetbrains", "idea", "pycharm", "clion", "webstorm", "android-studio",
    "kate", "kwrite", "gedit", "gnome-text-editor", "sublime", "zed",
    "konsole", "gnome-terminal", "kgx", "ptyxis", "kitty", "alacritty", "foot", "wezterm", "tilix",
    "xterm", "terminator", "terminal",
]

DEFAULTS = {
    "enabled": True,
    "limit_minutes": 60,
    "break_minutes": 30,
    "idle_threshold_seconds": 120,
    "warn_seconds": 60,
    "camera_enabled": True,
    "camera_index": 0,
    "presence_action": "pause",
    "max_lock_minutes": 120,
    "unlock_method": "tictactoe",
    "daily_goal_hours": 6.0,
    "eye_rest_enabled": True,
    "eye_rest_minutes": 20,
    "bedtime_enabled": False,
    "bedtime_start": "23:00",
    "bedtime_end": "06:00",
    "bedtime_limit_minutes": 15,
    "postpones_per_day": 2,
    "postpone_minutes": 10,
    "schedules_enabled": False,
    "schedules": [],
    "app_limits_enabled": False,
    "app_rules": [],
    "tray_enabled": True,
    "shortcut_created": False,
    "protected": DEFAULT_PROTECTED,
}

UNSAVED_FILE_RE = re.compile(
    r"(/\.~lock\..*#$)|(\.sw[a-p]$)|(/\.#[^/]+$)|(\.kate-swp$)|(~$)|(\.(part|crdownload|download|autosave)$)",
    re.I,
)
TITLE_RE = re.compile(r"^\s*[*•●✱◦]|[*•●]\s*$|\[\+\]|\(modified\)|\[modified\]|\bunsaved\b", re.I)

def create_shortcuts():
    content = (
        "[Desktop Entry]\nVersion=1.0\nType=Application\nName=RestWall\n"
        "Comment=Screen time limit, forced rest and usage statistics\n"
        'Exec="%s" "%s"\nIcon=preferences-system-time\nTerminal=false\nCategories=Utility;GTK;\n'
        % (sys.executable, os.path.abspath(__file__))
    )
    targets = [os.path.join(GLib.get_user_data_dir(), "applications", "restwall.desktop")]
    try:
        desk = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP)
    except Exception:
        desk = None
    desk = desk or os.path.join(os.path.expanduser("~"), "Desktop")
    if os.path.isdir(desk):
        targets.append(os.path.join(desk, "RestWall.desktop"))
    ok = False
    for t in targets:
        try:
            os.makedirs(os.path.dirname(t), exist_ok=True)
            with open(t, "w") as f:
                f.write(content)
            os.chmod(t, 0o755)
            ok = True
            if t.startswith(desk) and shutil.which("gio"):
                subprocess.run(["gio", "set", t, "metadata::trusted", "true"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        except (OSError, subprocess.SubprocessError):
            continue
    return ok


def set_autostart(on):
    try:
        if on:
            os.makedirs(os.path.dirname(AUTOSTART_FILE), exist_ok=True)
            with open(AUTOSTART_FILE, "w") as f:
                f.write(
                    "[Desktop Entry]\nType=Application\nName=RestWall\n"
                    'Exec="%s" "%s" --background\nX-GNOME-Autostart-enabled=true\n'
                    % (sys.executable, os.path.abspath(__file__))
                )
        elif os.path.exists(AUTOSTART_FILE):
            os.remove(AUTOSTART_FILE)
    except OSError:
        pass


class SessionInfo:
    def __init__(self):
        self.user = self._bus(Gio.BusType.SESSION)
        self.system = self._bus(Gio.BusType.SYSTEM)
        self.source = None
        for src in ("mutter", "kde"):
            if self._idle(src) is not None:
                self.source = src
                break

    @staticmethod
    def _bus(kind):
        try:
            return Gio.bus_get_sync(kind, None)
        except GLib.Error:
            return None

    @staticmethod
    def _call(bus, dest, path, iface, method, params=None):
        if bus is None:
            return None
        try:
            r = bus.call_sync(dest, path, iface, method, params, None, Gio.DBusCallFlags.NONE, 800, None)
            return r.unpack()
        except GLib.Error:
            return None

    def _idle(self, src):
        if src == "mutter":
            r = self._call(self.user, "org.gnome.Mutter.IdleMonitor", "/org/gnome/Mutter/IdleMonitor/Core",
                           "org.gnome.Mutter.IdleMonitor", "GetIdletime")
        else:
            r = self._call(self.user, "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver",
                           "org.freedesktop.ScreenSaver", "GetSessionIdleTime")
        if r:
            try:
                return float(r[0]) / 1000.0
            except (TypeError, ValueError):
                return None
        return None

    def idle_seconds(self):
        return self._idle(self.source) if self.source else None

    def screen_locked(self):
        r = self._call(self.system, "org.freedesktop.login1", "/org/freedesktop/login1/session/auto",
                       "org.freedesktop.DBus.Properties", "Get",
                       GLib.Variant("(ss)", ("org.freedesktop.login1.Session", "LockedHint")))
        return bool(r and r[0])


DETECTORS = (
    ("haarcascade_frontalface_default.xml", 5, 60, False),
    ("haarcascade_frontalface_alt2.xml", 4, 60, False),
    ("haarcascade_profileface.xml", 5, 60, True),
    ("haarcascade_upperbody.xml", 3, 120, False),
)


def find_cascade(name):
    dirs = []
    try:
        dirs.append(cv2.data.haarcascades)
    except Exception:
        pass
    dirs += ["/usr/share/opencv4/haarcascades", "/usr/share/opencv/haarcascades",
             "/usr/local/share/opencv4/haarcascades", "/usr/share/OpenCV/haarcascades"]
    for d in dirs:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return None


def open_camera(index):
    for i in [index] + [j for j in range(4) if j != index]:
        cap = cv2.VideoCapture(i, cv2.CAP_V4L2)
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            good = False
            for _ in range(6):
                ok, _f = cap.read()
                good = good or ok
            if good:
                return cap
        cap.release()
    return None


class Presence:
    def __init__(self):
        self.state = "off"
        self.detail = ""
        self._stop = None
        self._thread = None

    def start(self, index):
        self.stop()
        self.state, self.detail = "starting", ""
        if cv2 is None:
            self.state, self.detail = "unavailable", "OpenCV (python3-opencv) is not installed."
            return
        ev = threading.Event()
        self._stop = ev
        self._thread = threading.Thread(target=self._run, args=(ev, index), daemon=True)
        self._thread.start()

    def stop(self, join=False):
        if self._stop:
            self._stop.set()
            self._stop = None
        if join and self._thread:
            self._thread.join(timeout=3)
        self._thread = None
        self.state = "off"

    def _set(self, ev, state, detail=""):
        if not ev.is_set():
            self.state, self.detail = state, detail

    def _run(self, ev, index):
        cap = None
        try:
            cascades = []
            for name, nb, size, flip in DETECTORS:
                p = find_cascade(name)
                if p:
                    c = cv2.CascadeClassifier(p)
                    if not c.empty():
                        cascades.append((c, nb, size, flip))
            if not cascades:
                self._set(ev, "unavailable", "OpenCV detection models not found.")
                return
            hist = []
            while not ev.is_set():
                if cap is None:
                    cap = open_camera(index)
                    if cap is None:
                        self._set(ev, "unavailable", "Camera not available.")
                        ev.wait(3)
                        continue
                cap.grab()
                ok, frame = cap.read()
                if not ok:
                    cap.release()
                    cap = None
                    self._set(ev, "unavailable", "Camera read failed.")
                    ev.wait(2)
                    continue
                h, w = frame.shape[:2]
                if w > 640:
                    frame = cv2.resize(frame, (640, int(h * 640 / w)))
                gray = cv2.equalizeHist(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
                found = False
                for c, nb, size, flip in cascades:
                    for img in ((gray, cv2.flip(gray, 1)) if flip else (gray,)):
                        if len(c.detectMultiScale(img, scaleFactor=1.15, minNeighbors=nb, minSize=(size, size))):
                            found = True
                            break
                    if found:
                        break
                hist = (hist + [found])[-3:]
                self._set(ev, "present" if any(hist) else "away")
                ev.wait(1.2)
        except Exception as ex:
            self._set(ev, "unavailable", "Camera error: %s" % ex)
        finally:
            if cap is not None:
                cap.release()


class Enforcer:
    def __init__(self, engine):
        self.engine = engine
        self.scan = ProcScan()
        self.thread = None
        self.stop_ev = None
        self.reset()

    def reset(self):
        self.signalled, self.sigcount = {}, {}
        self.spared, self.initial = set(), set()
        self.safe = set()

    def start(self):
        self.stop()
        self.reset()
        self.safe = self_pids()
        ev = threading.Event()
        self.stop_ev = ev
        self.thread = threading.Thread(target=self._loop, args=(ev,), daemon=True)
        self.thread.start()

    def stop(self):
        if self.stop_ev:
            self.stop_ev.set()
            self.stop_ev = None
        if self.thread:
            self.thread.join(timeout=3)
            self.thread = None

    def _loop(self, ev):
        first = True
        while not ev.is_set():
            try:
                self.sweep(first)
            except Exception as ex:
                print("restwall enforce:", ex, file=sys.stderr)
            first = False
            ev.wait(2)

    @staticmethod
    def _group(pid, children):
        out, todo = [], [pid]
        while todo and len(out) < 200:
            q = todo.pop()
            out.append(q)
            todo.extend(children.get(q, []))
        return out

    @staticmethod
    def _unsaved(group, titles):
        for q in group:
            try:
                for fd in os.listdir("/proc/%d/fd" % q)[:400]:
                    try:
                        tgt = os.readlink("/proc/%d/fd/%s" % (q, fd))
                    except OSError:
                        continue
                    if UNSAVED_FILE_RE.search(tgt):
                        return True
            except OSError:
                pass
            for t in titles.get(q, []):
                if TITLE_RE.search(t):
                    return True
        return False

    @staticmethod
    def _kill(pid, start, sig):
        info = proc_info(pid)
        if not info or info["start"] != start:
            return
        try:
            os.kill(pid, sig)
        except OSError:
            pass

    def sweep(self, initial):
        prot = [s.strip().lower() for s in self.engine.cfg["protected"] if s.strip()]
        now = time.time()
        apps, procs = self.scan.top_level_gui(self.safe)
        children = {}
        for pid, p in procs.items():
            children.setdefault(p["ppid"], []).append(pid)
        titles = None
        for p in apps:
            pid = p["pid"]
            names = [n.lower() for n in p["names"]]
            if any(s in n for s in SYSTEM_DENY for n in names) or any(s in n for s in prot for n in names):
                continue
            key = (pid, p["start"])
            if key in self.spared:
                continue
            if key in self.signalled:
                if now - self.signalled[key] >= GRACE:
                    if key in self.initial:
                        self.spared.add(key)
                    else:
                        n = self.sigcount.get(key, 1)
                        self._kill(pid, p["start"], signal.SIGKILL if n >= 3 else signal.SIGTERM)
                        self.sigcount[key] = n + 1
                        self.signalled[key] = now
                continue
            if initial:
                if titles is None:
                    titles = window_titles()
                if self._unsaved(self._group(pid, children), titles):
                    self.spared.add(key)
                    continue
                self.initial.add(key)
            self._kill(pid, p["start"], signal.SIGTERM)
            self.signalled[key] = now
            self.sigcount[key] = 1


class AppLimiter:
    """Closes apps that used up their daily limit (rules with action "close"). SIGTERM only."""

    def __init__(self, engine):
        self.e = engine
        self.scan = ProcScan()
        self.sig, self.spared = {}, set()

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                self.sweep()
            except Exception as ex:
                print("restwall limiter:", ex, file=sys.stderr)
            time.sleep(5)

    def _say(self, nid, title, body):
        GLib.idle_add(lambda: self.e.app.notify(nid, title, body) or False)

    def sweep(self):
        e = self.e
        if e.locked or not e.cfg["app_limits_enabled"]:
            return
        blocked = []
        for r in e.cfg["app_rules"]:
            key = str(r.get("app", "")).strip().lower()
            if r.get("action") == "close" and key and r.get("minutes", 0) > 0 \
                    and e.app_used(key) >= r["minutes"] * 60:
                blocked.append(key)
        if not blocked:
            return
        now = time.time()
        apps, procs = self.scan.top_level_gui(e.apps.safe)
        children = {}
        for pid, p in procs.items():
            children.setdefault(p["ppid"], []).append(pid)
        titles = None
        for p in apps:
            names = [n.lower() for n in p["names"]]
            if any(sd in n for sd in SYSTEM_DENY for n in names):
                continue
            display = e.apps.pretty(*p["names"])
            low = display.lower()
            if not any(b == low or b in low or any(b in n for n in names) for b in blocked):
                continue
            key = (p["pid"], p["start"])
            if key in self.spared:
                continue
            if key in self.sig:
                if now - self.sig[key] >= GRACE:
                    self.spared.add(key)
                    self._say("restwall-lim-" + display, "%s did not close" % display,
                              "It may be showing a save dialog. Close it yourself.")
                continue
            if titles is None:
                titles = window_titles()
            if Enforcer._unsaved(Enforcer._group(p["pid"], children), titles):
                self.spared.add(key)
                self._say("restwall-lim-" + display, "%s left open" % display,
                          "Its daily limit is used up, but it may have unsaved work. Save and close it.")
                continue
            Enforcer._kill(p["pid"], p["start"], signal.SIGTERM)
            self.sig[key] = now


class Engine:
    def __init__(self, app):
        self.app = app
        self.cfg = load_json(CFG_FILE, DEFAULTS)
        self.state = load_json(STATE_FILE, {
            "date": today(), "total": 0.0, "session": 0.0, "goal_notified": "",
            "lock_remaining": 0.0, "lock_saved_at": 0.0, "lock_elapsed": 0.0,
        })
        self.stats = Stats(STATS_FILE)
        self.sess = SessionInfo()
        self.presence = Presence()
        self.enforcer = Enforcer(self)
        self.apps = ActiveApp(self_pids())
        self.apps.start()
        old = self.cfg.pop("app_limits", None)
        if old and not self.cfg.get("app_rules"):
            self.cfg["app_rules"] = [{"app": k, "minutes": int(v), "action": "notify"} for k, v in old.items()]
            self.cfg["app_limits_enabled"] = True
        self.limiter = AppLimiter(self)
        self.limiter.start()
        self.prev_sched = False
        self.locked = False
        self.warned = False
        self.was_bed = False
        self.was_present = False
        self.rest_run = 0.0
        self.eye_run = 0.0
        self.lock_not_before = 0.0
        self.app_notified = {}
        self.lock_remaining = 0.0
        self.lock_total = 0.0
        self.lock_elapsed = 0.0
        self.ticks = 0
        self.last = boot()
        rem = float(self.state.get("lock_remaining", 0))
        if rem > 0:
            rem -= max(0.0, time.time() - float(self.state.get("lock_saved_at", 0)))
            if rem > 0:
                GLib.idle_add(self._resume, rem, float(self.state.get("lock_elapsed", 0)))
            else:
                self.state["lock_remaining"] = 0.0
                self.state["session"] = 0.0
        GLib.timeout_add(1000, self.tick)

    def _resume(self, rem, el):
        self.start_lock(rem, el)
        return False

    def set(self, key, value):
        self.cfg[key] = value
        save_json(CFG_FILE, self.cfg)
        if key in ("limit_minutes", "warn_seconds", "bedtime_limit_minutes"):
            self.warned = False

    def persist(self):
        if self.locked:
            self.state["lock_remaining"] = self.lock_remaining
            self.state["lock_elapsed"] = self.lock_elapsed
            self.state["lock_saved_at"] = time.time()
        save_json(STATE_FILE, self.state)
        self.stats.save()

    def reset_counters(self):
        self.state["total"] = 0.0
        self.state["session"] = 0.0
        self.warned = False
        self.persist()

    def in_bedtime(self):
        if not self.cfg["bedtime_enabled"]:
            return False
        s = parse_hm(self.cfg["bedtime_start"], datetime.time(23, 0))
        e = parse_hm(self.cfg["bedtime_end"], datetime.time(6, 0))
        n = datetime.datetime.now().time()
        return (s <= n < e) if s < e else (n >= s or n < e)

    def active_schedule(self):
        cfg = self.cfg
        if not cfg["schedules_enabled"]:
            return None
        now = datetime.datetime.now()
        wd, t = now.weekday(), now.time()
        for r in cfg["schedules"]:
            if not r.get("enabled", True):
                continue
            st = parse_hm(r.get("start", "00:00"), datetime.time(0, 0))
            en = parse_hm(r.get("end", "23:59"), datetime.time(23, 59))
            days = r.get("days", [])
            if st < en:
                ok = wd in days and st <= t < en
            else:
                ok = (wd in days and t >= st) or ((wd - 1) % 7 in days and t < en)
            if ok:
                return r
        return None

    def effective_limit(self):
        rule = self.active_schedule()
        lim = (rule.get("limit_minutes", 0) if rule else self.cfg["limit_minutes"]) * 60
        if self.in_bedtime():
            b = self.cfg["bedtime_limit_minutes"] * 60
            lim = b if lim <= 0 else min(lim, b)
        return lim

    def break_seconds(self):
        rule = self.active_schedule()
        mins = (rule.get("break_minutes") if rule else 0) or self.cfg["break_minutes"]
        return mins * 60

    def app_used(self, key):
        return sum(v for k, v in self.stats.day()["apps"].items() if key == k.lower() or key in k.lower())

    def tray_state(self):
        lim = self.effective_limit()
        left = lim - self.state["session"]
        if self.locked:
            line = "Resting - %d min left" % math.ceil(max(self.lock_remaining, 0) / 60)
        elif not self.cfg["enabled"]:
            line = "Monitoring paused"
        elif lim <= 0:
            line = "No time limit right now"
        elif left >= 60:
            line = "%d min until next break" % math.ceil(left / 60)
        else:
            line = "Break starting soon"
        return {"line": line, "locked": self.locked, "enabled": self.cfg["enabled"],
                "postpones": self.postpones_left(), "postpone_minutes": self.cfg["postpone_minutes"]}

    def postpones_left(self):
        return max(0, self.cfg["postpones_per_day"] - self.stats.day()["postponed"])

    def postpone(self):
        if self.locked or self.postpones_left() <= 0:
            return False
        self.state["session"] = max(0.0, self.state["session"] - self.cfg["postpone_minutes"] * 60)
        self.stats.add("postponed", 1)
        self.warned = False
        self.app.notify("restwall-postponed", "Break postponed",
                        "You have about %d more minutes." % self.cfg["postpone_minutes"])
        return True

    def tick(self):
        now = boot()
        dt = max(0.0, now - self.last)
        self.last = now
        try:
            d = today()
            if self.state.get("date") != d:
                self.state["date"] = d
                self.state["total"] = 0.0
            if self.locked:
                self.tick_locked(dt)
            elif self.cfg["enabled"]:
                self.tick_active(dt)
            self.ticks += 1
            if self.ticks % 5 == 0:
                self.persist()
                self.app.refresh_tray()
            self.app.refresh_main()
        except Exception as ex:
            print("restwall:", ex, file=sys.stderr)
        return True

    def tick_active(self, dt):
        now = time.time()
        cfg = self.cfg
        asleep = dt > 5
        idle = self.sess.idle_seconds()
        prev = self.rest_run
        if asleep or self.sess.screen_locked():
            self.rest_run += dt
            counting = False
        elif idle is not None:
            self.rest_run = idle
            counting = idle < cfg["idle_threshold_seconds"]
        else:
            self.rest_run = 0.0
            counting = True
        new = self.rest_run
        if new >= AWAY_MIN:
            add = new if prev < AWAY_MIN else max(0.0, new - prev)
            if add > 0:
                self.stats.add("away", add)
        if prev >= AWAY_MIN and new < AWAY_MIN:
            self.stats.add("sessions", 1)
        if asleep or (idle is not None and idle >= 20):
            self.eye_run = 0.0
        if new >= self.break_seconds() and self.state["session"] > 0:
            self.stats.maxset("longest", self.state["session"])
            self.state["session"] = 0.0
            self.warned = False
            self.eye_run = 0.0

        if counting:
            d = min(dt, 2.0)
            self.state["total"] += d
            self.state["session"] += d
            self.eye_run += d
            self.stats.add("screen", d)
            for name in list(self.apps.current):
                self.stats.add_app(name, d)
            self.check_extras(now)

        bed = self.in_bedtime()
        if bed and not self.was_bed:
            self.lock_not_before = now + max(cfg["warn_seconds"], 60)
            self.app.notify("restwall-bed", "Bedtime mode",
                            "Your screen time limit is now %d minutes." % cfg["bedtime_limit_minutes"])
        self.was_bed = bed

        rule = self.active_schedule()
        key = rule.get("name", "") if rule else None
        if key != self.prev_sched:
            self.prev_sched = key
            if rule:
                self.lock_not_before = now + max(cfg["warn_seconds"], 60)
                self.app.notify("restwall-sched", "Schedule: %s" % key,
                                "Limit %s, rest %d min." % (
                                    "%d min" % rule.get("limit_minutes", 0) if rule.get("limit_minutes", 0) else "none",
                                    self.break_seconds() // 60))
        limit = self.effective_limit()
        s = self.state["session"]
        warn = cfg["warn_seconds"]
        if not self.warned and 0 < warn < limit and limit - warn <= s < limit:
            self.warned = True
            self.app.notify("restwall-warn", "Rest break soon",
                            "A forced break starts in about %d seconds. Save your work." % warn,
                            postpone=self.postpones_left() > 0)
        if limit > 0 and s >= limit and now >= self.lock_not_before:
            self.start_lock()

    def check_extras(self, now):
        cfg = self.cfg
        if cfg["eye_rest_enabled"] and self.eye_run >= cfg["eye_rest_minutes"] * 60:
            self.eye_run = 0.0
            self.app.notify("restwall-eyes", "Eye break",
                            "Look at something 20 feet (6 m) away for 20 seconds.")
        goal = cfg["daily_goal_hours"] * 3600
        if goal > 0 and self.state["total"] >= goal and self.state.get("goal_notified") != today():
            self.state["goal_notified"] = today()
            self.app.notify("restwall-goal", "Daily goal reached",
                            "You reached your daily screen time goal of %s." % fmt(goal))
        if cfg["app_limits_enabled"] and cfg["app_rules"]:
            for name in list(self.apps.current):
                low = name.lower()
                for r in cfg["app_rules"]:
                    key = str(r.get("app", "")).strip().lower()
                    mins = r.get("minutes", 0)
                    if not key or mins <= 0 or not (key == low or key in low):
                        continue
                    left = mins * 60 - self.app_used(key)
                    close = r.get("action") == "close"
                    if close and 0 < left <= 60 and now - self.app_notified.get((key, "soon"), 0) > 300:
                        self.app_notified[(key, "soon")] = now
                        self.app.notify("restwall-soon-" + key, "%s closes in about a minute" % name,
                                        "Its daily limit is almost used up. Save your work.")
                    elif left <= 0 and now - self.app_notified.get((key, "limit"), 0) > 900:
                        self.app_notified[(key, "limit")] = now
                        self.app.notify("restwall-app-" + key, "%s: daily limit reached" % name,
                                        "It will be closed." if close else "Time for something else?")

    def tick_locked(self, dt):
        credit = dt
        present = self.presence.state == "present" if self.cfg["camera_enabled"] else False
        if present and not self.was_present:
            self.stats.add("caught", 1)
        self.was_present = present
        if dt <= 5 and present:
            credit = 0.0
            if self.cfg["presence_action"] == "restart":
                self.lock_remaining = self.lock_total
        eff = min(credit, max(self.lock_remaining, 0.0))
        if eff > 0:
            self.stats.add("rest", eff)
        self.lock_remaining -= credit
        self.lock_elapsed += dt
        cap = max(self.cfg["max_lock_minutes"] * 60, self.break_seconds())
        if self.lock_remaining <= 0 or self.lock_elapsed >= cap:
            self.unlock()
            return
        self.push_lock_ui()

    def push_lock_ui(self):
        frac = 1.0 - self.lock_remaining / max(self.lock_total, 1.0)
        self.app.update_lock(self.lock_remaining, self.lock_view(), frac)

    def lock_view(self):
        cfg = self.cfg
        v = {"mode": "rest", "title": "Get some rest", "timer_note": "", "chip": "",
             "sub": "Get up and step away from the computer for %d minutes." % (self.break_seconds() // 60)}
        if not cfg["camera_enabled"]:
            return v
        st = self.presence.state
        if st == "present":
            restart = cfg["presence_action"] == "restart"
            v.update(mode="alert", title="Get off the computer!",
                     sub="The camera can see you. Stand up and walk away. "
                         + ("The rest timer restarts." if restart else "The rest timer is paused until you leave."),
                     chip="Camera: person detected",
                     timer_note="TIMER RESTARTED" if restart else "TIMER PAUSED")
        elif st == "away":
            v["chip"] = "Camera: nobody in view"
        elif st == "unavailable":
            v["chip"] = (self.presence.detail or "Camera unavailable.") + " Timer running."
        else:
            v["chip"] = "Camera: starting..."
        return v

    def start_lock(self, remaining=None, elapsed=0.0):
        if self.locked:
            return
        self.locked = True
        self.stats.maxset("longest", self.state["session"])
        self.lock_remaining = remaining if remaining is not None else self.break_seconds()
        self.lock_elapsed = elapsed
        self.lock_total = self.break_seconds()
        self.was_present = False
        self.last = boot()
        if self.cfg["camera_enabled"]:
            self.presence.start(self.cfg["camera_index"])
        self.enforcer.start()
        self.app.show_lock()
        self.persist()

    def unlock(self, emergency=False):
        if not self.locked:
            return
        self.locked = False
        if emergency:
            self.stats.add("emergency", 1)
        elif self.lock_remaining <= 0:
            self.stats.add("breaks", 1)
        else:
            self.stats.add("cut_short", 1)
        self.enforcer.stop()
        self.presence.stop()
        self.state["session"] = 0.0
        self.state["lock_remaining"] = 0.0
        self.state["lock_elapsed"] = 0.0
        self.warned = False
        self.rest_run = 0.0
        self.eye_run = 0.0
        self.last = boot()
        self.persist()
        self.app.hide_lock()
        self.app.notify("restwall-done", "Rest complete", "Welcome back. The screen time counter was reset.")


class RestWall(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.engine = None
        self.main = None
        self.locks = []
        self.tray = None
        self.first = True

    def do_startup(self):
        Gtk.Application.do_startup(self)
        apply_theme()
        act = Gio.SimpleAction.new("postpone", None)
        act.connect("activate", lambda a, p: self.engine and self.engine.postpone())
        self.add_action(act)

    def do_activate(self):
        if self.engine is None:
            self.engine = Engine(self)
            self.hold()
            e = self.engine
            if not e.cfg.get("shortcut_created") and create_shortcuts():
                e.set("shortcut_created", True)
            self.tray = Tray({
                "open": self.show_main, "toggle": self.toggle_main, "rest": e.start_lock,
                "postpone": e.postpone, "pause": lambda: e.set("enabled", not e.cfg["enabled"]),
                "quit": lambda: None if e.locked else self.quit(),
            }, e.tray_state)
            if e.cfg["tray_enabled"]:
                self.tray.start()
            Gdk.Display.get_default().get_monitors().connect("items-changed", self.on_monitors)
        if self.first and BACKGROUND:
            self.first = False
            return
        self.first = False
        self.show_main()

    def show_main(self):
        if self.main is None:
            self.main = MainWindow(self, self.engine)
        self.main.present()

    def toggle_main(self):
        if self.main is not None and self.main.get_visible():
            self.main.set_visible(False)
        else:
            self.show_main()

    def refresh_tray(self):
        if self.tray is not None:
            self.tray.refresh()

    def do_shutdown(self):
        if self.engine:
            if self.tray:
                self.tray.stop()
            self.engine.presence.stop(join=True)
            self.engine.enforcer.stop()
            self.engine.persist()
        Gtk.Application.do_shutdown(self)

    def on_monitors(self, *_a):
        if self.engine and self.engine.locked:
            GLib.idle_add(lambda: self.show_lock() or False)

    def refresh_main(self):
        if self.main is not None and self.main.get_visible():
            self.main.refresh()

    def show_lock(self):
        self.hide_lock()
        mons = Gdk.Display.get_default().get_monitors()
        n = mons.get_n_items()
        for i in range(max(n, 1)):
            w = LockWindow(self, mons.get_item(i) if n else None, i == 0)
            self.locks.append(w)
            w.present()
        self.engine.push_lock_ui()

    def hide_lock(self):
        for w in self.locks:
            w.alive = False
            w.destroy()
        self.locks = []

    def update_lock(self, remaining, view, fraction):
        spared = len(self.engine.enforcer.spared)
        for w in self.locks:
            w.set_info(view, fmt_ms(remaining), fraction, spared, remaining)

    def autostart_enabled(self):
        return os.path.exists(AUTOSTART_FILE)

    def set_autostart(self, on):
        set_autostart(on)

    def create_shortcuts(self):
        return create_shortcuts()

    def notify(self, nid, title, body, postpone=False):
        try:
            n = Gio.Notification.new(title)
            n.set_body(body)
            if postpone:
                n.add_button("Postpone", "app.postpone")
            self.send_notification(nid, n)
        except Exception:
            pass


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    return RestWall().run([sys.argv[0]])


if __name__ == "__main__":
    sys.exit(main())
