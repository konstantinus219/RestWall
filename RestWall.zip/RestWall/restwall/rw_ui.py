import datetime
import importlib.util
import math
import random
import re

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk  # noqa: E402

try:
    gi.require_version("Gtk4LayerShell", "1.0")
    from gi.repository import Gtk4LayerShell as LayerShell  # noqa: E402
except (ValueError, ImportError):
    LayerShell = None

from rw_common import fmt  # noqa: E402
from rw_stats import StatsPage  # noqa: E402
from rw_theme import (A1, A2, BAD1, BAD2, HAS_CAIRO, OFF1, OFF2, OK1, OK2, Ring, bar_row)  # noqa: E402

HAS_CV2 = importlib.util.find_spec("cv2") is not None

TIPS = [
    "Stand up and stretch your back and shoulders.",
    "Drink a glass of water.",
    "Look out of a window and focus on something far away.",
    "Walk around for a few minutes.",
    "Roll your wrists and shoulders slowly.",
    "Take a few slow, deep breaths.",
]

LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6))


def fmt_hm(sec):
    sec = int(max(0, sec))
    h, m = sec // 3600, sec % 3600 // 60
    return "%dh %02dm" % (h, m) if h else "%dm" % m


def ttt_winner(b):
    for x, y, z in LINES:
        if b[x] and b[x] == b[y] == b[z]:
            return b[x]
    return "draw" if all(b) else None


def ttt_ai(b):
    def finish(mark):
        for line in LINES:
            vals = [b[i] for i in line]
            if vals.count(mark) == 2 and vals.count("") == 1:
                return line[vals.index("")]
        return None

    m = finish("O")
    if m is None and random.random() < 0.6:
        m = finish("X")
    return m if m is not None else random.choice([i for i, c in enumerate(b) if not c])


def _label(text, css, xalign=0.0, **kw):
    lbl = Gtk.Label(label=text, xalign=xalign, **kw)
    for c in css.split():
        lbl.add_css_class(c)
    return lbl


def _button(text, css, cb=None, **kw):
    b = Gtk.Button(label=text, **kw)
    for c in css.split():
        b.add_css_class(c)
    if cb:
        b.connect("clicked", cb)
    return b


def _scrolled(child):
    sw = Gtk.ScrolledWindow(vexpand=True, hexpand=True)
    sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sw.set_child(child)
    return sw


def _page(spacing=16):
    return Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing,
                   margin_top=26, margin_bottom=26, margin_start=30, margin_end=30)


class TicTacToe(Gtk.Box):
    def __init__(self, on_win):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12, halign=Gtk.Align.CENTER)
        self.on_win = on_win
        self.status = _label("", "rw-sub", 0.5)
        grid = Gtk.Grid(row_spacing=8, column_spacing=8, halign=Gtk.Align.CENTER)
        self.cells = []
        for i in range(9):
            b = Gtk.Button()
            b.add_css_class("rw-ttt-cell")
            b.connect("clicked", self.on_click, i)
            grid.attach(b, i % 3, i // 3, 1, 1)
            self.cells.append(b)
        self.append(self.status)
        self.append(grid)
        self.reset()

    def _mark(self, i, m):
        self.board[i] = m
        self.cells[i].set_label(m)
        self.cells[i].add_css_class("rw-ttt-x" if m == "X" else "rw-ttt-o")

    def reset(self):
        self.board = [""] * 9
        self.busy = False
        for b in self.cells:
            b.set_label("")
            b.remove_css_class("rw-ttt-x")
            b.remove_css_class("rw-ttt-o")
        self.status.set_label("Beat the computer to unlock. You are X.")

    def _later_reset(self, text):
        self.busy = True
        self.status.set_label(text)
        GLib.timeout_add(1300, lambda: self.reset() or False)

    def on_click(self, _b, i):
        if self.busy or self.board[i]:
            return
        self._mark(i, "X")
        w = ttt_winner(self.board)
        if w == "X":
            self.busy = True
            self.status.set_label("You win!")
            self.on_win()
            return
        if w == "draw":
            self._later_reset("Draw. Try again.")
            return
        self._mark(ttt_ai(self.board), "O")
        w = ttt_winner(self.board)
        if w == "O":
            self._later_reset("The computer won. Try again.")
        elif w == "draw":
            self._later_reset("Draw. Try again.")


class LockWindow(Gtk.Window):
    def __init__(self, app, monitor, primary):
        super().__init__(application=app)
        self.app = app
        self.alive = True
        self._alert = False
        self.set_decorated(False)
        self.add_css_class("rw-lock")
        self.connect("close-request", lambda w: True)
        cfg = app.engine.cfg

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14,
                      halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.badge = _label("REST BREAK", "rw-badge", 0.5)
        self.ring = Ring(size=300, thick=14, pulse=True)
        self.timer = _label("--:--", "rw-timer", 0.5)
        self.timer_note = _label("", "rw-timer-note", 0.5)
        self.ring.center.append(self.timer)
        self.ring.center.append(self.timer_note)
        self.title_l = _label("Get some rest", "rw-title", 0.5)
        self.sub = _label("", "rw-sub", 0.5, wrap=True, justify=Gtk.Justification.CENTER, max_width_chars=60)
        self.timer_small = _label("", "rw-timer-small", 0.5)
        self.timer_small.set_visible(False)
        self.chip = _label("", "rw-lockchip", 0.5, halign=Gtk.Align.CENTER)
        self.tip = _label("", "rw-sub", 0.5, wrap=True, justify=Gtk.Justification.CENTER)
        self.tipcard = Gtk.Box(halign=Gtk.Align.CENTER, margin_top=6)
        self.tipcard.add_css_class("rw-tipcard")
        self.tipcard.append(self.tip)
        self.note = _label("", "rw-small", 0.5)
        for w in (self.badge, self.ring, self.title_l, self.sub, self.timer_small, self.chip, self.tipcard, self.note):
            box.append(w)

        self.emg_box = None
        method = cfg.get("unlock_method", "tictactoe")
        if primary and method in ("type", "tictactoe"):
            self.emg_btn = _button("Emergency exit", "rw-btn-ghost rw-emg", self.toggle_emergency,
                                   halign=Gtk.Align.CENTER, margin_top=10)
            self.emg_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.CENTER, visible=False)
            if method == "type":
                en = Gtk.Entry(placeholder_text="Type UNLOCK and press Enter", width_chars=30,
                               halign=Gtk.Align.CENTER)
                en.connect("activate", self.on_type)
                self.emg_box.append(en)
            else:
                self.emg_box.append(TicTacToe(self.unlock))
            box.append(self.emg_btn)
            box.append(self.emg_box)
        self.set_child(box)

        layered = False
        if LayerShell is not None and monitor is not None:
            try:
                layered = LayerShell.is_supported()
            except Exception:
                layered = False
        if layered:
            LayerShell.init_for_window(self)
            LayerShell.set_namespace(self, "restwall")
            LayerShell.set_layer(self, LayerShell.Layer.OVERLAY)
            for edge in (LayerShell.Edge.TOP, LayerShell.Edge.BOTTOM, LayerShell.Edge.LEFT, LayerShell.Edge.RIGHT):
                LayerShell.set_anchor(self, edge, True)
            LayerShell.set_exclusive_zone(self, -1)
            LayerShell.set_keyboard_mode(
                self, LayerShell.KeyboardMode.EXCLUSIVE if primary else LayerShell.KeyboardMode.NONE)
            LayerShell.set_monitor(self, monitor)
        else:
            try:
                if monitor is not None:
                    self.fullscreen_on_monitor(monitor)
                else:
                    self.fullscreen()
            except Exception:
                self.fullscreen()
            GLib.timeout_add_seconds(1, self.keep_front)

    def keep_front(self):
        if not self.alive:
            return False
        if not self.is_active():
            self.present()
        return True

    def toggle_emergency(self, _b):
        show = not self.emg_box.get_visible()
        self.emg_box.set_visible(show)
        for w in (self.ring, self.tipcard, self.note):
            w.set_visible(not show)
        self.timer_small.set_visible(show)
        self.emg_btn.set_label("Hide emergency exit" if show else "Emergency exit")

    def on_type(self, entry):
        if entry.get_text().strip().upper() == "UNLOCK":
            self.unlock()

    def unlock(self):
        GLib.idle_add(lambda: self.app.engine.unlock(True) or False)

    def set_info(self, view, timer, fraction, spared, remaining):
        alert = view["mode"] == "alert"
        if alert != self._alert:
            self._alert = alert
            (self.add_css_class if alert else self.remove_css_class)("rw-alert")
        self.badge.set_label("CAMERA ALERT" if alert else "REST BREAK")
        self.title_l.set_label(view["title"])
        self.sub.set_label(view["sub"])
        self.timer.set_label(timer)
        self.timer_small.set_label(timer + " left")
        self.timer_note.set_label(view["timer_note"])
        self.ring.set_state(fraction, BAD1 if alert else OK1, BAD2 if alert else OK2)
        self.chip.set_label(view["chip"])
        self.chip.set_visible(bool(view["chip"]))
        self.tip.set_label(TIPS[int(remaining // 45) % len(TIPS)])
        self.note.set_label("%d app(s) kept open because they may contain unsaved work." % spared if spared else "")


class MainWindow(Gtk.ApplicationWindow):
    NAV = (("overview", "Overview", "\u25c9"), ("stats", "Statistics", "\u25a4"), ("settings", "Settings", "\u2699"))
    DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    def __init__(self, app, engine):
        super().__init__(application=app, title="RestWall")
        self.e = engine
        self.rw = app
        self.n = 0
        self.test_left = 0.0
        self.spins, self.pills = {}, {}
        self.add_css_class("rw-main")
        self.set_default_size(1060, 740)
        self.connect("close-request", lambda w: w.set_visible(False) or True)

        hb = Gtk.HeaderBar()
        hb.set_title_widget(_label("REST WALL", "rw-titlebar", 0.5))
        self.set_titlebar(hb)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=200,
                               hexpand=True, vexpand=True)
        root = Gtk.Box()
        root.append(self.build_side())
        root.append(self.stack)
        self.set_child(root)
        self.stats_page = StatsPage(engine)
        self.stack.add_named(_scrolled(self.build_overview()), "overview")
        self.stack.add_named(_scrolled(self.stats_page), "stats")
        self.stack.add_named(_scrolled(self.build_settings()), "settings")
        self.go("overview")
        self.refresh()

    # ---- navigation
    def build_side(self):
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        side.add_css_class("rw-side")
        side.set_size_request(230, -1)
        logo = Gtk.Label(label='REST<span foreground="#19d3ff">\u25cf</span>WALL', use_markup=True, xalign=0,
                         margin_bottom=22, margin_start=8)
        logo.add_css_class("rw-logo")
        side.append(logo)
        self.nav = {}
        for name, text, glyph in self.NAV:
            b = _button("%s   %s" % (glyph, text), "rw-nav", lambda btn, n=name: self.go(n))
            b.get_child().set_xalign(0)
            self.nav[name] = b
            side.append(b)
        side.append(Gtk.Box(vexpand=True))
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin_bottom=8)
        card.add_css_class("rw-side-card")
        card.append(_label("STATUS", "rw-cap"))
        self.side_state = _label("", "rw-row-title", wrap=True)
        card.append(self.side_state)
        side.append(card)
        side.append(_button("Quit RestWall", "rw-btn-ghost",
                            lambda b: None if self.e.locked else self.rw.quit()))
        return side

    def go(self, name):
        self.stack.set_visible_child_name(name)
        for n, b in self.nav.items():
            (b.add_css_class if n == name else b.remove_css_class)("active")

    # ---- overview
    @staticmethod
    def _tile_card(title):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        card.add_css_class("rw-card")
        card.append(_label(title.upper(), "rw-cap"))
        value = _label("", "rw-tile-value")
        sub = _label("", "rw-hint", wrap=True)
        card.append(value)
        card.append(sub)
        return card, value, sub

    def build_overview(self):
        page = _page(18)
        head = Gtk.Box(spacing=12)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True)
        self.greet = _label("", "rw-h1")
        self.date = _label("", "rw-hint")
        left.append(self.greet)
        left.append(self.date)
        self.chip = _label("", "rw-chip", valign=Gtk.Align.CENTER)
        head.append(left)
        head.append(self.chip)
        page.append(head)

        cols = Gtk.Box(spacing=18)
        hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, hexpand=True)
        hero.add_css_class("rw-card")
        hero.add_css_class("rw-card-glow")
        self.ring = Ring(size=280, thick=16, pulse=True)
        self.ring_big = _label("", "rw-ring-big", 0.5)
        self.ring_cap = _label("", "rw-ring-cap", 0.5)
        self.ring.center.append(self.ring_big)
        self.ring.center.append(self.ring_cap)
        self.hero_sub = _label("", "rw-hint", 0.5)
        hero.append(self.ring)
        hero.append(self.hero_sub)
        actions = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER, margin_top=4)
        actions.append(_button("Take a break now", "rw-btn-primary", lambda b: self.e.start_lock()))
        self.btn_postpone = _button("", "rw-btn", lambda b: self.e.postpone())
        self.btn_pause = _button("", "rw-btn",
                                 lambda b: self.e.set("enabled", not self.e.cfg["enabled"]))
        actions.append(self.btn_postpone)
        actions.append(self.btn_pause)
        hero.append(actions)
        cols.append(hero)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        right.set_size_request(340, -1)
        card, self.v_screen, self.s_screen = self._tile_card("Screen time today")
        self.goal_bar = Gtk.ProgressBar(margin_top=4)
        card.append(self.goal_bar)
        right.append(card)
        card, self.v_rest, self.s_rest = self._tile_card("Rested today")
        right.append(card)
        apps = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        apps.add_css_class("rw-card")
        apps.append(_label("TOP APPS TODAY", "rw-cap"))
        self.top_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        apps.append(self.top_box)
        self.now = _label("", "rw-hint", wrap=True)
        apps.append(self.now)
        right.append(apps)
        cols.append(right)
        page.append(cols)
        return page

    def _set_chip(self, text, kind=""):
        for c in ("rw-chip-rest", "rw-chip-off", "rw-chip-warn"):
            self.chip.remove_css_class(c)
        if kind:
            self.chip.add_css_class("rw-chip-" + kind)
        self.chip.set_label(text.upper())

    # ---- settings
    def build_settings(self):
        cfg = self.e.cfg
        page = _page(10)
        page.append(_label("Settings", "rw-h1"))
        self.card = None

        def section(title, glow=False):
            page.append(_label(title.upper(), "rw-h2", margin_top=12))
            self.card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            self.card.add_css_class("rw-card")
            if glow:
                self.card.add_css_class("rw-card-glow")
            page.append(self.card)

        def row(title, hint, widget):
            if self.card.get_first_child() is not None:
                self.card.append(Gtk.Separator(margin_top=4, margin_bottom=4))
            r = Gtk.Box(spacing=14, margin_top=4, margin_bottom=4)
            txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True, valign=Gtk.Align.CENTER)
            txt.append(_label(title, "rw-row-title"))
            if hint:
                txt.append(_label(hint, "rw-hint", wrap=True))
            widget.set_valign(Gtk.Align.CENTER)
            r.append(txt)
            r.append(widget)
            self.card.append(r)

        def spin(key, lo, hi, step=1, digits=0):
            s = Gtk.SpinButton.new_with_range(lo, hi, step)
            s.set_digits(digits)
            s.set_value(cfg[key])

            def changed(w):
                self.e.set(key, w.get_value() if digits else int(w.get_value()))
                self._sync_pills(key)

            s.connect("value-changed", changed)
            self.spins[key] = s
            return s

        def switch(key):
            sw = Gtk.Switch(active=bool(cfg[key]))
            sw.connect("notify::active", lambda w, _p: self.e.set(key, w.get_active()))
            return sw

        def segmented(key, options):
            box = Gtk.Box()
            box.add_css_class("rw-seg")
            first = None
            vals = [v for v, _l in options]
            for val, label in options:
                b = Gtk.ToggleButton(label=label)
                if first is None:
                    first = b
                else:
                    b.set_group(first)
                b.set_active(cfg[key] == val or (cfg[key] not in vals and first is b))
                b.connect("toggled", lambda w, v=val: w.get_active() and self.e.set(key, v))
                box.append(b)
            return box

        def timeentry(key):
            en = Gtk.Entry(text=cfg[key], width_chars=6, max_width_chars=6)

            def changed(w):
                t = w.get_text().strip()
                if re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", t):
                    self.e.set(key, t)

            en.connect("changed", changed)
            return en

        section("Quick setup", glow=True)
        self.card.append(self._pill_row("limit_minutes", "Take a break after", "Minutes of screen time", (30, 45, 60, 90, 120)))
        self.card.append(Gtk.Separator(margin_top=10, margin_bottom=10))
        self.card.append(self._pill_row("break_minutes", "Rest for", "Minutes away from the screen", (5, 10, 15, 30)))

        section("Screen time")
        row("Monitor screen time", "Turn counting and breaks on or off.", switch("enabled"))
        row("Break after", "Minutes of screen time before a forced rest.", spin("limit_minutes", 1, 720))
        row("Rest length", "Minutes you have to stay away.", spin("break_minutes", 1, 240))
        row("Warn me", "Seconds of notice before the break starts.", spin("warn_seconds", 0, 600))
        row("Count as idle after", "Seconds without input before counting stops.", spin("idle_threshold_seconds", 10, 1800))
        row("Daily goal", "Hours per day. 0 turns the goal off.", spin("daily_goal_hours", 0, 24, 0.5, 1))
        row("Postpones per day", "How many times you can delay a break.", spin("postpones_per_day", 0, 10))
        row("Postpone length", "Minutes added each time.", spin("postpone_minutes", 1, 60))

        section("Schedules (optional)")
        row("Use schedules", "Different limits for certain days and hours. Outside every schedule your normal "
                             "limit applies. A limit of 0 means no limit during that schedule.",
            switch("schedules_enabled"))
        self.sched_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=8)
        self.card.append(self.sched_box)
        self.card.append(_button("+ Add schedule", "rw-btn", self.add_schedule, halign=Gtk.Align.START, margin_top=8))
        self.fill_schedules()

        section("Camera guard")
        guard = switch("camera_enabled")
        row("Camera guard", "Uses the camera during the rest to check that you left. Turn it off if it annoys you; "
                            "the rest timer then just counts down.", guard)
        deps = []
        w = segmented("presence_action", [("pause", "Pause timer"), ("restart", "Restart timer")])
        deps.append(w)
        row("If the camera sees you", "What happens to the rest timer when a person is detected.", w)
        w = spin("camera_index", 0, 9)
        deps.append(w)
        row("Camera number", "Try 1 if the wrong camera is used.", w)
        self.cam_label = _label("", "rw-hint", 1.0)
        cam_box = Gtk.Box(spacing=10)
        cam_box.append(self.cam_label)
        cam_box.append(_button("Test camera", "rw-btn", self.test_camera))
        deps.append(cam_box)
        row("Camera test", "Shows what the camera sees for 10 seconds.", cam_box)

        def sync_guard(*_a):
            for d in deps:
                d.set_sensitive(guard.get_active())

        guard.connect("notify::active", sync_guard)
        sync_guard()

        section("Rest lock")
        row("Emergency exit", "How to leave the rest wall early.",
            segmented("unlock_method", [("none", "None"), ("type", "Type UNLOCK"), ("tictactoe", "Tic-tac-toe")]))
        row("Longest lock", "Safety limit in minutes, even if the camera keeps seeing you.",
            spin("max_lock_minutes", 1, 720))

        section("Wellbeing")
        row("Eye breaks", "Reminder to look 20 feet away for 20 seconds.", switch("eye_rest_enabled"))
        row("Eye break every", "Minutes of active screen time.", spin("eye_rest_minutes", 5, 120))
        row("Bedtime mode", "Use a shorter limit during the night.", switch("bedtime_enabled"))
        row("Bedtime starts", "24-hour time, HH:MM.", timeentry("bedtime_start"))
        row("Bedtime ends", "24-hour time, HH:MM.", timeentry("bedtime_end"))
        row("Limit at bedtime", "Minutes before a break during bedtime.", spin("bedtime_limit_minutes", 1, 240))

        section("App limits (optional)")
        row("Use app limits", "A daily time limit per app, separate from the screen time limit. Use the app name "
                              "shown in Statistics. Close the app never force-kills: apps with unsaved work stay open.",
            switch("app_limits_enabled"))
        self.app_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=8)
        self.card.append(self.app_box)
        self.card.append(_button("+ Add app limit", "rw-btn", self.add_app_rule, halign=Gtk.Align.START, margin_top=8))
        self.fill_apps()

        section("Apps")
        prot = Gtk.Entry(text=", ".join(cfg["protected"]), width_chars=30)
        prot.connect("changed", lambda w: self.e.set(
            "protected", [s.strip() for s in w.get_text().split(",") if s.strip()]))
        row("Never close these apps", "Comma separated names. Video editors, office apps and editors are listed by default.", prot)

        section("General")
        auto = Gtk.Switch(active=self.rw.autostart_enabled())
        auto.connect("notify::active", lambda w, _p: self.rw.set_autostart(w.get_active()))
        row("Start at login", "Runs in the background after you sign in.", auto)
        tray = Gtk.Switch(active=bool(cfg["tray_enabled"]))

        def tray_toggled(w, _p):
            self.e.set("tray_enabled", w.get_active())
            self.rw.tray.set_enabled(w.get_active())

        tray.connect("notify::active", tray_toggled)
        row("Tray icon", "", tray)
        self.tray_hint = _label("", "rw-hint", wrap=True)
        self.card.append(self.tray_hint)

        def make_shortcut(b):
            b.set_label("Created" if self.rw.create_shortcuts() else "Failed")

        row("Desktop shortcut", "Adds RestWall to your desktop and app menu. Done automatically on first launch.",
            _button("Create again", "rw-btn", make_shortcut))
        row("Reset today's counters", "Sets today's screen time and the break counter back to zero.",
            _button("Reset", "rw-btn rw-btn-danger", lambda b: self.e.reset_counters()))

        layer_ok = False
        try:
            layer_ok = LayerShell is not None and LayerShell.is_supported()
        except Exception:
            pass
        page.append(_label("Idle detection: %s | Rest wall: %s | Camera: %s | Charts: %s" % (
            self.e.sess.source or "none (counts while unlocked)",
            "layer-shell overlay" if layer_ok else "fullscreen window",
            "OpenCV ready" if HAS_CV2 else "OpenCV missing",
            "on" if HAS_CAIRO else "basic (install python3-gi-cairo)"), "rw-hint", wrap=True, margin_top=10))
        return page

    def _pill_row(self, key, title, hint, values):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.append(_label(title, "rw-row-title"))
        box.append(_label(hint, "rw-hint"))
        pills = Gtk.Box(spacing=8)
        first, items = None, []
        for v in values:
            b = Gtk.ToggleButton(label="%d min" % v)
            b.add_css_class("rw-pill")
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.set_active(self.e.cfg[key] == v)
            b.connect("toggled", self._pill_toggled, key, v)
            pills.append(b)
            items.append((b, v))
        self.pills[key] = items
        box.append(pills)
        return box

    def _pill_toggled(self, btn, key, v):
        if btn.get_active():
            self.e.set(key, v)
            if key in self.spins:
                self.spins[key].set_value(v)

    def _sync_pills(self, key):
        for b, v in self.pills.get(key, []):
            b.set_active(self.e.cfg[key] == v)

    # ---- list editors
    @staticmethod
    def _clear(box):
        c = box.get_first_child()
        while c is not None:
            nxt = c.get_next_sibling()
            box.remove(c)
            c = nxt

    def _save(self, key):
        self.e.set(key, self.e.cfg[key])

    def _rule_set(self, rule, key, val, list_key):
        rule[key] = val
        self._save(list_key)

    def _rule_delete(self, rule, list_key, refill):
        lst = self.e.cfg[list_key]
        if rule in lst:
            lst.remove(rule)
            self._save(list_key)
        GLib.idle_add(lambda: refill() or False)

    def _num(self, rule, key, lo, hi, list_key):
        sp = Gtk.SpinButton.new_with_range(lo, hi, 1)
        sp.set_value(rule.get(key, lo))
        sp.connect("value-changed", lambda w: self._rule_set(rule, key, int(w.get_value()), list_key))
        return sp

    def _time(self, rule, key):
        en = Gtk.Entry(text=rule.get(key, ""), width_chars=6, max_width_chars=6)

        def changed(w):
            t = w.get_text().strip()
            if re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", t):
                self._rule_set(rule, key, t, "schedules")

        en.connect("changed", changed)
        return en

    def _empty(self, box, text):
        box.append(_label(text, "rw-hint"))

    def add_schedule(self, _b):
        self.e.cfg["schedules"].append({
            "name": "Work hours", "enabled": True, "days": [0, 1, 2, 3, 4], "start": "09:00", "end": "17:00",
            "limit_minutes": 90, "break_minutes": 10})
        self._save("schedules")
        self.fill_schedules()

    def fill_schedules(self):
        self._clear(self.sched_box)
        rules = self.e.cfg["schedules"]
        if not rules:
            self._empty(self.sched_box, "No schedules yet.")
        for r in rules:
            self.sched_box.append(self._sched_card(r))

    def _sched_card(self, rule):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.add_css_class("rw-subcard")
        top = Gtk.Box(spacing=10)
        sw = Gtk.Switch(active=rule.get("enabled", True), valign=Gtk.Align.CENTER)
        sw.connect("notify::active", lambda w, _p: self._rule_set(rule, "enabled", w.get_active(), "schedules"))
        name = Gtk.Entry(text=rule.get("name", ""), hexpand=True, placeholder_text="Name")
        name.connect("changed", lambda w: self._rule_set(rule, "name", w.get_text(), "schedules"))
        for w in (sw, name, _button("Delete", "rw-btn-ghost rw-btn-danger",
                                    lambda b: self._rule_delete(rule, "schedules", self.fill_schedules))):
            top.append(w)
        days = Gtk.Box(spacing=6)
        for i, d in enumerate(self.DAYS):
            t = Gtk.ToggleButton(label=d, active=i in rule.get("days", []))
            t.add_css_class("rw-pill")
            t.connect("toggled", self._day_toggled, rule, i)
            days.append(t)
        r1, r2 = Gtk.Box(spacing=10), Gtk.Box(spacing=10)
        for box, items in ((r1, (("From", self._time(rule, "start")), ("to", self._time(rule, "end")))),
                           (r2, (("Limit in minutes (0 = none)", self._num(rule, "limit_minutes", 0, 720, "schedules")),
                                 ("Rest in minutes", self._num(rule, "break_minutes", 1, 240, "schedules"))))):
            for text, w in items:
                box.append(_label(text, "rw-hint", valign=Gtk.Align.CENTER))
                box.append(w)
        for w in (top, days, r1, r2):
            card.append(w)
        return card

    def _day_toggled(self, btn, rule, i):
        days = set(rule.get("days", []))
        (days.add if btn.get_active() else days.discard)(i)
        rule["days"] = sorted(days)
        self._save("schedules")

    def add_app_rule(self, _b):
        self.e.cfg["app_rules"].append({"app": "", "minutes": 60, "action": "notify"})
        self._save("app_rules")
        self.fill_apps()

    def fill_apps(self):
        self._clear(self.app_box)
        rules = self.e.cfg["app_rules"]
        if not rules:
            self._empty(self.app_box, "No app limits yet.")
        for r in rules:
            self.app_box.append(self._app_card(r))

    def _app_card(self, rule):
        card = Gtk.Box(spacing=10)
        card.add_css_class("rw-subcard")
        name = Gtk.Entry(text=rule.get("app", ""), hexpand=True, placeholder_text="App name, e.g. Firefox")
        name.connect("changed", lambda w: self._rule_set(rule, "app", w.get_text().strip(), "app_rules"))
        act = Gtk.Box()
        act.add_css_class("rw-seg")
        first = None
        for val, label in (("notify", "Notify"), ("close", "Close app")):
            b = Gtk.ToggleButton(label=label)
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.set_active(rule.get("action", "notify") == val)
            b.connect("toggled", lambda w, v=val: w.get_active() and self._rule_set(rule, "action", v, "app_rules"))
            act.append(b)
        for w in (name, self._num(rule, "minutes", 1, 1440, "app_rules"), _label("min/day", "rw-hint", valign=Gtk.Align.CENTER),
                  act, _button("Delete", "rw-btn-ghost rw-btn-danger",
                               lambda b: self._rule_delete(rule, "app_rules", self.fill_apps))):
            card.append(w)
        return card

    # ---- camera test
    def test_camera(self, _b):
        if self.e.locked:
            return
        self.e.presence.start(self.e.cfg["camera_index"])
        self.test_left = 10.0
        self.cam_label.set_label("Starting camera...")
        GLib.timeout_add(500, self._test_tick)

    def _test_tick(self):
        if self.e.locked:
            return False
        self.test_left -= 0.5
        if self.test_left <= 0:
            self.e.presence.stop()
            self.cam_label.set_label("Test finished")
            return False
        st = self.e.presence.state
        self.cam_label.set_label({
            "present": "Person detected", "away": "Nobody in view", "starting": "Starting camera...",
            "unavailable": self.e.presence.detail or "Camera unavailable"}.get(st, st))
        return True

    # ---- live refresh
    def refresh(self):
        e = self.e
        s = e.state
        d = e.stats.day()
        lim = e.effective_limit()
        left = lim - s["session"]
        rule = e.active_schedule()
        now = datetime.datetime.now()
        hour = now.hour
        self.greet.set_label("Good morning" if hour < 12 else "Good afternoon" if hour < 18 else "Good evening")
        self.date.set_label(now.strftime("%A, %d %B"))

        if e.locked:
            frac = 1.0 - e.lock_remaining / max(e.lock_total, 1.0)
            rem = max(e.lock_remaining, 0)
            self._set_chip("Resting", "rest")
            self.ring.set_state(frac, OK1, OK2)
            big, cap = "%02d:%02d" % (int(rem) // 60, int(rem) % 60), "REST LEFT"
            sub = "Step away from the computer"
        elif not e.cfg["enabled"]:
            self._set_chip("Paused", "off")
            self.ring.set_state(0.0, OFF1, OFF2)
            big, cap, sub = "Off", "MONITORING PAUSED", "Resume monitoring to start counting"
        elif lim <= 0:
            self._set_chip("Schedule: " + rule.get("name", "") if rule else "No limit")
            self.ring.set_state(0.0, A1, A2)
            big, cap, sub = "\u221e", "NO LIMIT RIGHT NOW", "%s since your last rest" % fmt(s["session"])
        else:
            frac = min(1.0, s["session"] / lim)
            self._set_chip("Bedtime mode" if e.in_bedtime() else ("Schedule: " + rule.get("name", "") if rule else "Monitoring"),
                           "warn" if frac >= 0.85 else "")
            self.ring.set_state(frac, BAD1 if frac >= 0.85 else A1, BAD2 if frac >= 0.85 else A2)
            big = str(math.ceil(left / 60)) if left >= 60 else "<1"
            cap = "MIN UNTIL BREAK"
            sub = "%s used of %s since your last rest" % (fmt(s["session"]), fmt(lim))
        self.ring_big.set_label(big)
        self.ring_cap.set_label(cap)
        self.hero_sub.set_label(sub)
        self.side_state.set_label(cap.capitalize() if e.locked or not e.cfg["enabled"] else
                                  ("%s min until break" % big if lim > 0 else "No limit right now"))

        goal = e.cfg["daily_goal_hours"] * 3600
        self.v_screen.set_label(fmt_hm(s["total"]))
        if goal > 0:
            self.s_screen.set_label("Goal %s | streak %d day(s)" % (fmt_hm(goal), e.stats.streak(goal)))
            self.goal_bar.set_fraction(min(1.0, s["total"] / goal))
            self.goal_bar.set_visible(True)
        else:
            self.s_screen.set_label("No daily goal set")
            self.goal_bar.set_visible(False)
        self.v_rest.set_label(fmt_hm(d["rest"] + d["away"]))
        self.s_rest.set_label("%d break(s) completed | %d postponed" % (d["breaks"], d["postponed"]))

        if self.n % 5 == 0:
            self._clear(self.top_box)
            top = sorted(d["apps"].items(), key=lambda x: -x[1])[:4]
            if not top:
                self._empty(self.top_box, "No data yet.")
            for i, (name, secs) in enumerate(top, 1):
                self.top_box.append(bar_row(name, fmt_hm(secs), secs / top[0][1], rank=i))
        cur = e.apps.current
        self.now.set_label("Using now: " + (", ".join(cur) if cur else "-"))

        left_p = e.postpones_left()
        self.btn_postpone.set_label("Postpone +%d min (%d left)" % (e.cfg["postpone_minutes"], left_p))
        self.btn_postpone.set_sensitive(left_p > 0 and not e.locked)
        self.btn_pause.set_label("Pause" if e.cfg["enabled"] else "Resume")
        if self.rw.tray is not None:
            self.tray_hint.set_label(self.rw.tray.status_text())
        self.n += 1
        if self.n % 5 == 0:
            self.stats_page.refresh()
