RestWall V2.1 - digital wellbeing for Linux (GTK4 / Wayland)
Screen time limit, forced rest wall, camera presence check, per-app usage, rest statistics.

SETUP

Step 1: Install dependencies (pick your distro)
  Debian/Ubuntu: sudo apt install python3 python3-gi gir1.2-gtk-4.0 python3-opencv python3-gi-cairo libgtk4-layer-shell0 gir1.2-gtk4layershell-1.0
  Fedora:        sudo dnf install python3-gobject python3-cairo gtk4 python3-opencv gtk4-layer-shell
  Arch:          sudo pacman -S python-gobject python-cairo gtk4 python-opencv gtk4-layer-shell

Step 2: unzip "rest wall V2.1.zip"

Step 3: cd restwall

Step 4: ./install.sh

Step 5: restwall

The first launch creates a RestWall shortcut on your Desktop and in the app menu.

Run without installing: python3 restwall.py
Start hidden (autostart): restwall --background

FILES

  restwall.py     app, engine, lock wall, main window
  rw_common.py    helpers, process scanner
  rw_stats.py     statistics, active-app tracking, statistics page
  rw_ui.py        windows: dashboard, settings, rest wall, tic-tac-toe
  rw_tray.py      system tray icon and menu
  rw_theme.py     stylesheet, progress ring, chart
  install.sh      installs to ~/.local

  ~/.config/restwall/config.json        settings
  ~/.local/share/restwall/state.json    counters and active lock (survives restart/crash)
  ~/.local/share/restwall/stats.json    daily history (120 days)
  ~/RestWall-export/                    CSV export (daily.csv, apps.csv)

FEATURES

  V2.1 design: dark glass theme, sidebar navigation, live progress ring with glow, weekly bar chart,
    ranked app bars, quick-setup presets, segmented switches, cinematic rest wall with a pulsing countdown ring.
    The ring and chart need python3-gi-cairo (python3-cairo on Fedora/Arch); without it they fall back to plain bars.

  Overview: time until next break, screen time today, rest today, most used app, daily goal and streak,
    Take a break now / Postpone / Pause monitoring.
  Statistics (Today / 7 days / 30 days): time per app, rest taken, time away, breaks, longest session,
    times caught by the camera, 7-day chart, CSV export.
  Settings (grouped, each option explained): screen time, rest lock and camera, wellbeing, apps, general.
    - Camera guard: on/off switch (Settings > Camera guard), what happens when it sees you (pause or restart the timer), camera number, Test camera button.
    - Emergency exit: None / Type UNLOCK / Tic-tac-toe puzzle (win against the computer; draw or loss resets the board).
    - Eye breaks (20-20-20), bedtime mode, daily goal, postpones, app daily limits, protected apps, start at login.
  New in V2 (all optional, off or adjustable in Settings):
    - Tray icon: time until next break in the tooltip, menu with Open / Take a break / Postpone / Pause / Quit.
      Works on KDE, Sway, Hyprland (waybar etc.). GNOME needs the AppIndicator extension.
    - Schedules: limit and rest length per weekday and hours (limit 0 = no limit). Overnight ranges work.
    - App limits: daily minutes per app, Notify only or Close the app (SIGTERM, never force-kill;
      apps with unsaved work stay open and you get a notification).
  Notifications: break warning (with Postpone button), eye break, goal reached, app limit, bedtime, rest complete.

BEHAVIOR

  - Counts screen time while the session is active (idle, suspended or locked time is not counted).
  - Idle detection: GNOME (Mutter) and KDE Plasma. Other compositors count time while the session is unlocked.
  - The limit applies to time since the last rest. Idle/locked/suspended for the rest length resets it.
  - At the limit: fullscreen "Get some rest" wall with countdown and rotating rest tips.
  - Wall: wlr-layer-shell overlay (Sway, Hyprland, KDE, etc.). GNOME has no layer-shell, so a refocusing fullscreen window is used.
  - Camera (OpenCV: face, profile and upper-body detection) runs only while the rest wall is up.
    When it sees a person the wall turns red, shows "Get off the computer!" and the 30 minute timer
    stops (or restarts, your choice). It continues when you are out of view.
  - If the camera is unavailable the countdown runs normally.
  - The lock survives restart and suspend; time asleep counts as rest.
  - Apps are closed with SIGTERM (clean close). Never force-killed unless launched during the lock and unresponsive.
  - Not closed: protected list (Kdenlive, video editors, LibreOffice, editors/IDEs, terminals, ...),
    desktop/system components, apps with lock/swap/partial-download files open,
    apps with modified-looking window titles (Sway/Hyprland), apps that survive SIGTERM (e.g. "Save changes?" dialog).
  - Apps launched during the lock are closed repeatedly until the timer ends.

  Per-app tracking source (shown in the Statistics tab):
    - Sway, Hyprland: focused window.
    - GNOME: focused window with the "Window Calls" or "Focused Window D-Bus" extension installed.
    - KDE: focused window with kdotool installed.
    - Otherwise: time each app is open.
  - Per-app time counts only while you are active (not idle).
