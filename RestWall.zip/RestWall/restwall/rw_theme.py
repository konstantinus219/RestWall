import math
import sys
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

try:
    import cairo
    gi.require_foreign("cairo")
    HAS_CAIRO = True
except Exception:
    cairo = None
    HAS_CAIRO = False

A1, A2 = (0.486, 0.361, 1.0), (0.098, 0.827, 1.0)      # violet -> cyan
OK1, OK2 = (0.20, 0.90, 0.62), (0.10, 0.72, 1.0)        # green -> blue
BAD1, BAD2 = (1.0, 0.36, 0.36), (1.0, 0.62, 0.22)       # red -> orange
OFF1, OFF2 = (0.55, 0.58, 0.68), (0.45, 0.48, 0.58)     # grey

CSS = """
window.rw-main, window.rw-lock { color: #eef0fa; background-color: #0a0e1f; }
window.rw-main { background-image: linear-gradient(135deg, #0a0e1f 0%, #101736 55%, #1b1245 100%); }
window.rw-main headerbar { background: transparent; background-image: none; box-shadow: none; border: none; color: #eef0fa; }
.rw-titlebar { font-weight: 700; letter-spacing: 2px; font-size: 12px; opacity: 0.7; }

.rw-side { background-color: rgba(6,9,24,0.60); border-right: 1px solid rgba(255,255,255,0.06); padding: 20px 14px; }
.rw-logo { font-size: 22px; font-weight: 800; letter-spacing: 1px; }
.rw-logo-dot { color: #19d3ff; }
.rw-nav { background-color: transparent; background-image: none; border: none; box-shadow: none; border-radius: 14px;
  padding: 11px 16px; color: rgba(238,240,250,0.62); font-weight: 600; font-size: 14px; }
.rw-nav:hover { background-color: rgba(255,255,255,0.06); color: #ffffff; }
.rw-nav.active { background-image: linear-gradient(90deg, rgba(124,92,255,0.38), rgba(25,211,255,0.14)); color: #ffffff;
  box-shadow: inset 3px 0 0 #19d3ff; }
.rw-side-card { background-color: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 12px 14px; }

.rw-card { background-color: rgba(255,255,255,0.055); border: 1px solid rgba(255,255,255,0.09); border-radius: 22px;
  padding: 18px 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.30); }
.rw-card-glow { background-image: linear-gradient(135deg, rgba(124,92,255,0.24), rgba(25,211,255,0.08));
  border: 1px solid rgba(124,92,255,0.40); }
.rw-subcard { background-color: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 12px 14px; }

.rw-h1 { font-size: 30px; font-weight: 800; }
.rw-h2 { font-size: 11px; font-weight: 800; letter-spacing: 2px; color: rgba(238,240,250,0.50); }
.rw-sec { font-size: 15px; font-weight: 800; }
.rw-cap { font-size: 11px; font-weight: 700; letter-spacing: 1px; color: rgba(238,240,250,0.52); }
.rw-tile-value { font-size: 28px; font-weight: 800; }
.rw-hint { font-size: 12px; color: rgba(238,240,250,0.55); }
.rw-row-title { font-weight: 600; }
.rw-rank { font-size: 11px; font-weight: 800; background-color: rgba(124,92,255,0.30); border-radius: 99px; padding: 1px 8px; }
.rw-ring-big { font-size: 58px; font-weight: 800; }
.rw-ring-cap { font-size: 12px; font-weight: 700; letter-spacing: 2px; color: rgba(238,240,250,0.55); }
.rw-chip { background-color: rgba(25,211,255,0.14); color: #7fe3ff; border-radius: 99px; padding: 4px 14px; font-size: 12px; font-weight: 800; letter-spacing: 1px; }
.rw-chip-rest { background-color: rgba(52,230,158,0.16); color: #7dffc4; }
.rw-chip-off { background-color: rgba(255,255,255,0.10); color: rgba(238,240,250,0.65); }
.rw-chip-warn { background-color: rgba(255,160,80,0.18); color: #ffc08a; }

progressbar trough { background-color: rgba(255,255,255,0.09); background-image: none; border: none; border-radius: 99px; min-height: 8px; }
progressbar progress { background-image: linear-gradient(90deg, #7c5cff, #19d3ff); border: none; border-radius: 99px; min-height: 8px; }

.rw-btn-primary { background-image: linear-gradient(90deg, #7c5cff, #19d3ff); color: #ffffff; font-weight: 800; border: none;
  border-radius: 16px; padding: 13px 24px; box-shadow: 0 8px 22px rgba(124,92,255,0.45); }
.rw-btn-primary:hover { box-shadow: 0 10px 30px rgba(25,211,255,0.55); }
.rw-btn { background-color: rgba(255,255,255,0.07); background-image: none; color: #eef0fa; font-weight: 600;
  border: 1px solid rgba(255,255,255,0.10); border-radius: 16px; padding: 12px 18px; box-shadow: none; }
.rw-btn:hover { background-color: rgba(255,255,255,0.13); }
.rw-btn:disabled { opacity: 0.40; }
.rw-btn-danger { color: #ff9a9a; }
.rw-btn-ghost { background-color: transparent; background-image: none; border: none; box-shadow: none; color: rgba(238,240,250,0.65);
  border-radius: 12px; padding: 8px 14px; font-weight: 600; }
.rw-btn-ghost:hover { background-color: rgba(255,255,255,0.07); color: #ffffff; }

.rw-pill, .rw-seg button { background-color: rgba(255,255,255,0.07); background-image: none; color: rgba(238,240,250,0.8);
  border: 1px solid rgba(255,255,255,0.10); box-shadow: none; font-weight: 700; padding: 7px 16px; }
.rw-pill { border-radius: 99px; }
.rw-seg button { border-radius: 0; }
.rw-seg button:first-child { border-radius: 12px 0 0 12px; }
.rw-seg button:last-child { border-radius: 0 12px 12px 0; }
.rw-pill:checked, .rw-seg button:checked { background-image: linear-gradient(90deg, #7c5cff, #19d3ff); color: #ffffff; border-color: transparent; }

window.rw-main entry, window.rw-main spinbutton, window.rw-lock entry {
  background-color: rgba(255,255,255,0.07); background-image: none; color: #eef0fa;
  border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; box-shadow: none; min-height: 34px; }
window.rw-main entry:focus-within, window.rw-main spinbutton:focus-within { border-color: #19d3ff; }
window.rw-main spinbutton button { background-image: none; background-color: transparent; border: none; box-shadow: none; color: #eef0fa; }
window.rw-main switch { background-color: rgba(255,255,255,0.14); background-image: none; border: none; border-radius: 99px;
  min-width: 50px; min-height: 26px; box-shadow: none; }
window.rw-main switch:checked { background-image: linear-gradient(90deg, #7c5cff, #19d3ff); }
window.rw-main switch slider { background-color: #ffffff; background-image: none; border: none; border-radius: 99px;
  min-width: 22px; min-height: 22px; box-shadow: 0 1px 3px rgba(0,0,0,0.45); }
window.rw-main scrolledwindow, window.rw-main viewport { background: transparent; background-image: none; }
window.rw-main scrollbar { background: transparent; }
window.rw-main scrollbar slider { background-color: rgba(255,255,255,0.25); border-radius: 99px; min-width: 6px; min-height: 40px; }
window.rw-main separator { background-color: rgba(255,255,255,0.08); }

window.rw-lock { background-image: linear-gradient(160deg, #070a18 0%, #0d1230 60%, #170f3a 100%); }
window.rw-lock.rw-alert { background-color: #1a0508; background-image: linear-gradient(160deg, #1a0508 0%, #3a0d12 60%, #5a1414 100%); }
.rw-badge { font-size: 13px; font-weight: 800; letter-spacing: 4px; color: #8fb4ff; }
window.rw-alert .rw-badge { color: #ffb4a8; }
.rw-title { font-size: 54px; font-weight: 800; color: #f2f4f8; }
.rw-sub { font-size: 20px; color: #b6bfd6; }
.rw-timer { font-size: 78px; font-weight: 300; color: #ffffff; }
.rw-timer-small { font-size: 28px; font-weight: 600; color: #7fd6a8; }
.rw-timer-note { font-size: 14px; font-weight: 800; letter-spacing: 3px; color: #ff9a8a; }
.rw-lockchip { font-size: 14px; color: #e8b86d; background-color: rgba(255,255,255,0.08); border-radius: 99px; padding: 5px 16px; }
.rw-tipcard { background-color: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 12px 22px; }
.rw-small { font-size: 13px; color: #7a8399; }
.rw-emg { opacity: 0.55; }
.rw-ttt-cell { font-size: 34px; font-weight: 800; min-width: 84px; min-height: 84px; border-radius: 18px;
  background-color: rgba(255,255,255,0.07); background-image: none; border: 1px solid rgba(255,255,255,0.14); color: #ffffff; box-shadow: none; }
.rw-ttt-cell:hover { background-color: rgba(255,255,255,0.14); }
.rw-ttt-x { color: #7fe3ff; }
.rw-ttt-o { color: #ff9fb0; }
"""


def apply_theme():
    try:
        Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", True)
    except Exception:
        pass
    prov = Gtk.CssProvider()
    prov.connect("parsing-error", lambda p, sec, err: print("restwall css:", err.message, file=sys.stderr))
    for load in (lambda: prov.load_from_string(CSS), lambda: prov.load_from_data(CSS, -1),
                 lambda: prov.load_from_data(CSS.encode())):
        try:
            load()
            break
        except Exception:
            continue
    Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


def bar_row(name, value_text, fraction, rank=None):
    row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
    top = Gtk.Box(spacing=10)
    if rank is not None:
        r = Gtk.Label(label=str(rank))
        r.add_css_class("rw-rank")
        top.append(r)
    top.append(Gtk.Label(label=name, xalign=0, hexpand=True))
    v = Gtk.Label(label=value_text, xalign=1)
    v.add_css_class("rw-hint")
    top.append(v)
    row.append(top)
    bar = Gtk.ProgressBar()
    bar.set_fraction(max(0.0, min(1.0, fraction)))
    row.append(bar)
    return row


class Ring(Gtk.Overlay):
    """Circular progress ring with a glowing pulse. Falls back to a bar without pycairo."""

    def __init__(self, size=260, thick=16, pulse=False):
        super().__init__()
        self.size, self.thick, self.pulse = size, thick, pulse
        self.fraction, self.c1, self.c2 = 0.0, A1, A2
        self._src = 0
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self.area = Gtk.DrawingArea()
        self.area.set_content_width(size)
        self.area.set_content_height(size)
        self.center = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.CENTER,
                              valign=Gtk.Align.CENTER, spacing=2)
        self.fallback = None
        if HAS_CAIRO:
            self.area.set_draw_func(self._draw)
        else:
            self.fallback = Gtk.ProgressBar(valign=Gtk.Align.END, margin_bottom=6, margin_start=20, margin_end=20)
            self.add_overlay(self.fallback)
        self.set_child(self.area)
        self.add_overlay(self.center)
        self.connect("map", self._on_map)
        self.connect("unmap", self._on_unmap)

    def set_state(self, fraction, c1, c2):
        self.fraction, self.c1, self.c2 = fraction, c1, c2
        if self.fallback is not None:
            self.fallback.set_fraction(max(0.0, min(1.0, fraction)))
        self.area.queue_draw()

    def _on_map(self, *_a):
        if self.pulse and HAS_CAIRO and not self._src:
            self._src = GLib.timeout_add(60, self._tick)

    def _on_unmap(self, *_a):
        if self._src:
            GLib.source_remove(self._src)
            self._src = 0

    def _tick(self):
        self.area.queue_draw()
        return True

    def _draw(self, area, cr, w, h):
        cx, cy = w / 2.0, h / 2.0
        r = min(w, h) / 2.0 - self.thick / 2.0 - 12
        c1, c2 = self.c1, self.c2
        if self.pulse:
            k = (math.sin(time.monotonic() * 0.9) + 1) / 2
            g = cairo.RadialGradient(cx, cy, r * 0.45, cx, cy, r * (1.12 + 0.10 * k))
            g.add_color_stop_rgba(0, *c1, 0.0)
            g.add_color_stop_rgba(0.80, *c1, 0.10 + 0.10 * k)
            g.add_color_stop_rgba(1, *c2, 0.0)
            cr.set_source(g)
            cr.arc(cx, cy, r * 1.25, 0, 2 * math.pi)
            cr.fill()
        cr.set_line_width(self.thick)
        cr.set_source_rgba(1, 1, 1, 0.08)
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.stroke()
        f = max(0.0, min(1.0, self.fraction))
        if f > 0.002:
            lg = cairo.LinearGradient(cx - r, cy - r, cx + r, cy + r)
            lg.add_color_stop_rgb(0, *c1)
            lg.add_color_stop_rgb(1, *c2)
            cr.set_source(lg)
            cr.set_line_cap(cairo.LINE_CAP_ROUND)
            ang = -math.pi / 2 + 2 * math.pi * f
            cr.arc(cx, cy, r, -math.pi / 2, ang)
            cr.stroke()
            cr.set_source_rgba(1, 1, 1, 0.95)
            cr.arc(cx + r * math.cos(ang), cy + r * math.sin(ang), self.thick * 0.28, 0, 2 * math.pi)
            cr.fill()


class BarChart(Gtk.DrawingArea):
    """Weekly chart: screen time (gradient) and rest (green) per day."""

    def __init__(self):
        super().__init__()
        self.set_content_height(200)
        self.set_hexpand(True)
        self.data = []
        if HAS_CAIRO:
            self.set_draw_func(self._draw)

    def set_data(self, data):
        self.data = data
        self.queue_draw()

    @staticmethod
    def _rrect(cr, x, y, w, h, r):
        r = max(0.0, min(r, w / 2.0, h / 2.0))
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
        cr.close_path()

    def _draw(self, area, cr, w, h):
        n = len(self.data)
        if not n:
            return
        peak = max([max(d[1], d[2]) for d in self.data] + [1.0])
        base, top = h - 26, 24
        slot = w / float(n)
        bw = min(46.0, slot * 0.62)
        sw, rw = bw * 0.60, bw * 0.32
        cr.select_font_face("Sans")
        cr.set_font_size(12)
        for i, (label, screen, rest) in enumerate(self.data):
            x0 = i * slot + (slot - bw) / 2.0
            self._rrect(cr, x0, top, sw, base - top, 8)
            cr.set_source_rgba(1, 1, 1, 0.05)
            cr.fill()
            hh = (base - top) * screen / peak
            if hh > 1:
                lg = cairo.LinearGradient(0, base - hh, 0, base)
                lg.add_color_stop_rgb(0, *A2)
                lg.add_color_stop_rgb(1, *A1)
                self._rrect(cr, x0, base - hh, sw, hh, 8)
                cr.set_source(lg)
                cr.fill()
            rh = (base - top) * rest / peak
            if rh > 1:
                self._rrect(cr, x0 + sw + bw * 0.08, base - rh, rw, rh, 6)
                cr.set_source_rgba(*OK1, 0.95)
                cr.fill()
            cr.set_source_rgba(1, 1, 1, 0.55)
            ext = cr.text_extents(label)
            cr.move_to(x0 + bw / 2.0 - ext.width / 2.0, h - 6)
            cr.show_text(label)
            if screen > 60:
                txt = "%.1fh" % (screen / 3600.0)
                ext = cr.text_extents(txt)
                cr.set_source_rgba(1, 1, 1, 0.8)
                cr.move_to(x0 + sw / 2.0 - ext.width / 2.0, max(14, base - hh - 6))
                cr.show_text(txt)
